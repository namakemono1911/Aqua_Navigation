﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CreateUIEditor : EditorWindow
{
    const string prefubAddr = "Assets/Prefub/Game/UI/createUITemplate.prefab";
    static private CreateUIEditor window = null;
    [SerializeField]
    private GameObject createObject = null;
    [SerializeField]
    private int numObject = 0;

    [MenuItem("Window/CreateUIEditor")]
    static void Open()
    {
        if (window == null)
            window = CreateInstance<CreateUIEditor>();
        window.Show();
    }

    // ウィンドウ内の描画内容
    private void OnGUI()
    {
        EditorGUILayout.BeginVertical();

        createObject = EditorGUILayout.ObjectField(
                createObject, typeof(GameObject), false) as GameObject;

        numObject = EditorGUILayout.IntSlider(numObject, 0, 99);

        if (GUILayout.Button("create"))
            createUI();

        EditorGUILayout.EndVertical();
    }

    // UI生成
    void createUI()
    {
        // エラーチェック
        if (createObject == null)
        {
            UnityEditor.EditorUtility.DisplayDialog("Oops!", "生成するオブジェクトが選択されていません", "ok");
            return;
        }

        var content = getContent();
        if (content == null)
            return;

        // 生成
        var ui = AssetDatabase.LoadMainAssetAtPath(prefubAddr) as GameObject;
        if (ui == null)
        {
            UnityEditor.EditorUtility.DisplayDialog("Oops!", "誰だプレハブ消したの！！", "ok");
            return;
        }
		ui.GetComponent<Image>().sprite = createObject.GetComponent<haveSprite>().HaveSprite;
        ui.GetComponent<remainingNumberController>().Remaining = numObject;
        ui.GetComponent<createButton>().CreateObject = createObject;
        ui = Instantiate(ui, content);
    }

    // ConetntのTransform取得
    private Transform getContent()
    {
        var objects = SceneManager.GetActiveScene().GetRootGameObjects();
        GameObject canvas = objects[0];
        for (int i = 0; canvas.name.Equals("Canvas") == false || objects.Length < i; i++)
            canvas = objects[i];

        if (canvas == null)
        {
            UnityEditor.EditorUtility.DisplayDialog("Oops!", "Canvasがありません", "ok");
            return null;
        }

        var content = canvas.transform.Find("Scroll View").Find("Viewport").Find("Content");
        if (content == null)
        {
            UnityEditor.EditorUtility.DisplayDialog("Oops!", "コンテンツを表示するためのUIがありません", "ok");
            return null;
        }

        return content;
    }
}

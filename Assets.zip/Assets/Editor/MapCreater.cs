﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Map creater 
/// </summary>
public class MapCreater : EditorWindow {

	// 地形画像ディレクトリ
	private Object imgDirectoryGround;
	// ギミック画像ディレクトリ
	private Object imgDirectoryGimmick;
	// 出力先ディレクトリ(nullだとAssets下に出力します)
	private Object outputDirectory;
	// マップエディタのマスの数
	private int mapSize = 10;
	// グリッドの大きさ、小さいほど細かくなる
	private float gridSize = 50.0f;
	// 出力ファイル名
	private string outputFileName;
	// 選択した画像パス
	private string selectedImagePath;
	// 選択した画像パスに付随するPrefub情報
	public struct IMAGE_PATH
	{
		public GameObject selectedImageObjects;
		public string selectedImagePaths;
		public float rad;   // 回転
		public bool flip;	// 反転
	};
	private IMAGE_PATH[] selectedObjects;
	private int selectedNumber = 0;
	// サブウィンドウ
	private MapCreaterSubWindow subWindow;
	// サブウィンドウのグリッドの色
	private Color gridColor = new Color(0,0,0,1);
	// マップの生成位置
	private GameObject stageObjects;
	// スクロールバーの位置
	private Vector2 scrollPosGround = new Vector2(0, 0);
	private Vector2 scrollPosGimmick = new Vector2(0, 0);
	// イメージ名とプレハブ名の対応表
	public struct IMAGE_2_PREFUB
	{
		public string image;
		public string prefub;
	};
	// イメージ名とプレハブ名の対応表
	private IMAGE_2_PREFUB[] image2prefubs;

	[UnityEditor.MenuItem("Window/MapCreater")]
	static void ShowTestMainWindow(){
		EditorWindow.GetWindow (typeof (MapCreater));
	}

	// GUI関係
	void OnGUI(){
		// 初期化
		GetImage2Prefub();
		SetPrefub2Image();
		// GUI
		mapSize = 12;

		GUILayout.Label("設定 : ", GUILayout.Width(110));

		GUILayout.BeginHorizontal();
		GUILayout.Label("ステージ生成場所 : ", GUILayout.Width(110));
		stageObjects = (GameObject)EditorGUILayout.ObjectField(stageObjects, typeof(Object), true);
		GUILayout.EndHorizontal();
		EditorGUILayout.Space();

		GUILayout.BeginHorizontal();
		GUILayout.Label("グリッド色 : ", GUILayout.Width(110));
		gridColor = EditorGUILayout.ColorField(gridColor);
		GUILayout.EndHorizontal();
		EditorGUILayout.Space();

		GUILayout.BeginHorizontal();
		GUILayout.Label("グリッドサイズ : ", GUILayout.Width(110));
		gridSize = EditorGUILayout.FloatField(gridSize);
		GUILayout.EndHorizontal();
		EditorGUILayout.Space();

		// 地形画像情報
		GUILayout.BeginHorizontal();
		GUILayout.Label("地形画像フォルダ : ", GUILayout.Width(110));
		imgDirectoryGround = EditorGUILayout.ObjectField(imgDirectoryGround, typeof(UnityEngine.Object), true);
		GUILayout.EndHorizontal();
		EditorGUILayout.Space();


		DrawImageGround();

        DrawSelectedImage();

		DrawMapWindowButton();
	}

	// 地形画像一覧をボタン選択出来る形にして出力
	private void DrawImageGround(){
		if(imgDirectoryGround != null){
			float fx = 50.0f;
			float x = fx;
			float y = 00.0f;
			float w = 50.0f;
			float h = 50.0f;
			float maxW = 400.0f;
			float pathW = 200.0f;

			string path = AssetDatabase.GetAssetPath(imgDirectoryGround);
			string[] names = Directory.GetFiles(path);
			string[] namesDel = Directory.GetFiles(path, "*.meta");
			int i = 0;
			int cntObj = 0;
			scrollPosGround = EditorGUILayout.BeginScrollView(scrollPosGround , GUI.skin.box);
			//EditorGUILayout.BeginHorizontal();

			if (selectedObjects == null)
			{
				selectedObjects = new IMAGE_PATH[names.Length - namesDel.Length];
				for (int n = 0; n < selectedObjects.Length; ++n)
				{
					selectedObjects[n].rad = 0.0f;
				}
			}

			foreach (string d in names)
			{
				// 除外設定
				if (i < namesDel.Length && d == namesDel[i])
				{
					++i;
					continue;
				}

				if (x > maxW)
				{
					x = fx;
					y += h;
					EditorGUILayout.EndHorizontal();
				}
				if (x == fx)
				{
					EditorGUILayout.BeginHorizontal();
				}

				//GUILayout.FlexibleSpace();
				Texture2D tex = (Texture2D)AssetDatabase.LoadAssetAtPath(d, typeof(Texture2D));
				if (GUILayout.Button(tex, GUILayout.MaxWidth(w), GUILayout.MaxHeight(h), GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false)))
				{
					selectedImagePath = d;
					selectedNumber = cntObj;
					selectedObjects[selectedNumber].rad = 0.0f;

				}
				//GUILayout.FlexibleSpace();

				selectedObjects[cntObj].selectedImageObjects = (GameObject)EditorGUILayout.ObjectField(selectedObjects[cntObj].selectedImageObjects, typeof(Object), GUILayout.Width(pathW));
				selectedObjects[cntObj].selectedImagePaths = d;

				++cntObj;

				x += (w+ pathW);
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.EndScrollView();
		}
	}

    // 選択した画像データを表示
    private void DrawSelectedImage(){
		if (selectedImagePath != null) {
			Texture2D tex = (Texture2D)AssetDatabase.LoadAssetAtPath (selectedImagePath, typeof(Texture2D));
			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			GUILayout.Label("select : " + selectedImagePath);

			GUIUtility.RotateAroundPivot(selectedObjects[selectedNumber].rad, new Vector2(Screen.width / 100.0f * 5, Screen.height /100.0f * 74.0f));
			GUILayout.Box(tex, GUILayout.Width(50), GUILayout.Height(50));

			GUI.matrix = Matrix4x4.identity;

			GUILayout.Label("回転角度 : ", GUILayout.Width(110));
            selectedObjects[selectedNumber].rad = EditorGUILayout.FloatField(selectedObjects[selectedNumber].rad);

			GUILayout.Label("反転 : ", GUILayout.Width(110));
			selectedObjects[selectedNumber].flip = EditorGUILayout.Toggle(selectedObjects[selectedNumber].flip);

			EditorGUILayout.EndVertical();
		}
	}

	// マップウィンドウを開くボタンを生成
	private void DrawMapWindowButton(){
		EditorGUILayout.BeginVertical();
		GUILayout.FlexibleSpace();
		if(GUILayout.Button("open map editor")){
			if(subWindow == null){
				subWindow = MapCreaterSubWindow.WillAppear(this);
			}else{
				subWindow.Focus();
			}
		}
		EditorGUILayout.EndVertical();
	}
	
	public string SelectedImagePath{
		get{ return selectedImagePath; }
	}

    // 選択している情報を渡す(イメージ)
    public string selectedInfoImage(string image)
	{
		image = selectedObjects[selectedNumber].selectedImagePaths;
		return image;
	}

    // 選択している情報を渡す(プレハブ)
	public GameObject selectedInfoObj(GameObject obj)
	{
		obj = selectedObjects[selectedNumber].selectedImageObjects;
		return obj;
	}
 
	// 選択している情報を渡す(回転)
    public float selectedInfoRad(float rad)
	{
		rad = selectedObjects[selectedNumber].rad;
		return rad;
	}

	// 選択している情報を渡す(反転)
	public bool selectedInfoFlip(bool flip)
	{
		flip = selectedObjects[selectedNumber].flip;
		return flip;
	}

	// マップの縦横数
	public int MapSize{
		get{ return mapSize; }
	}

    // マップのグリッドサイズ
    public float GridSize{
		get{ return gridSize; }
	}
 
	// グリッドカラー
	public Color GridColor {
		get { return gridColor; }
	}
 
	// 選択している情報(イメージとプレハブと回転の1セット)
	public GameObject StageInstance
	{
		get { return stageObjects; }
	}
    
	// 読み込んでいる情報(イメージとプレハブと回転の1セット)
    public IMAGE_PATH[] ObjectCount()
	{
		return selectedObjects;
	}
	
	// 出力先パスを生成
	public string OutputFilePath(){
		string resultPath = "";
		if(outputDirectory != null){
			resultPath = AssetDatabase.GetAssetPath(outputDirectory);
		}else{
			resultPath = Application.dataPath;
		}

		return resultPath + "/" + outputFileName + ".txt"; 
	}

	// イメージ名とプレハブ名を結びつける情報を取得
	private void GetImage2Prefub()
    {
        string filePath = "mapEditor/mapEditorInit";    // ファイルパス
        TextAsset ta = new TextAsset();                     // テキストファイルデータ格納
		string textData;                                    // テキスト全体の文字列
		string[] textMessage;								// テキスト加工前の１行をいれる
		int rowLength;                                      // 行数
		int cntImage2PrefubLength = 0;
		// 区切り文字
		string object_ground = "#OBJECT_GROUND\r";
		string object_gimmick = "#OBJECT_GIMMICK\r";
		string comment = "*";

		ta = Resources.Load(filePath, typeof(TextAsset)) as TextAsset;
		// 全体を取り込む
		textData = ta.text;
		// 1行づつに分解
		textMessage = textData.Split('\n');
		// 行数と列数を取得
		rowLength = textMessage.Length;
		// 対応表の数取得
		for (int i = 0; i < rowLength; ++i)
		{
			if (textMessage[i] == object_ground || textMessage[i] == object_gimmick)
			{
				++cntImage2PrefubLength;
			}
		}
		image2prefubs = new IMAGE_2_PREFUB[cntImage2PrefubLength];

		cntImage2PrefubLength = 0;
		// 対応表格納
		for (int i = 0; i < rowLength; ++i)
		{
			if (textMessage[i] == object_ground || textMessage[i] == object_gimmick)
			{
				++i;

				while (textMessage[i].StartsWith(comment))
				{
					++i;
				}

				image2prefubs[cntImage2PrefubLength].image = textMessage[i];
				image2prefubs[cntImage2PrefubLength].image = image2prefubs[cntImage2PrefubLength].image.Replace("\r", "");
				++i;

				while (textMessage[i].StartsWith(comment))
				{
					++i;
				}
				image2prefubs[cntImage2PrefubLength].prefub = textMessage[i];
				image2prefubs[cntImage2PrefubLength].prefub = image2prefubs[cntImage2PrefubLength].prefub.Replace("\r", "");

				++cntImage2PrefubLength;
			}
		}
	}

	// 画像名からプレハブをセット
	private void SetPrefub2Image()
	{
		if (selectedObjects == null)
			return;

		for(int i = 0; i < selectedObjects.Length; ++i)
		{
			// 対応表から画像名検索でプレハブ名を出す
			string prefub = searchIndexImage2Puurefub(image2prefubs, selectedObjects[i].selectedImagePaths);

			if(prefub == null)
			{
				Debug.Log("MapCreater : その画像は存在しません。 : " + selectedObjects[i].selectedImagePaths.ToString());
				continue;
			}

			// プレハブ名と一致するものをプレハブディレクトリから検索
			selectedObjects[i].selectedImageObjects = searchPrefubInDirectory(prefub, selectedObjects[i].selectedImageObjects);

			if (selectedObjects[i].selectedImageObjects == null)
			{
				Debug.Log("MapCreater : [Resources/Prefub]そのプレハブは存在しません。 : " + prefub);
			}
		}
	}

	// イメージ名検索して該当プレハブ名を返す
	private string searchIndexImage2Puurefub(IMAGE_2_PREFUB[] img, string imgName)
	{
		for (int i = 0; i < img.Length; ++i)
		{
			if (imgName.Contains(img[i].image))
			{
				return img[i].prefub;
			}
		}
		return null;
	}

	//プレハブ名からプレハブを検索
	private GameObject searchPrefubInDirectory(string prefub , GameObject gmObj)
	{
		string p = "Prefub/" + prefub;
		gmObj = Resources.Load(p) as GameObject;
		return gmObj;
	}
}

/// <summary>
/// Map creater sub window.
/// </summary>
public class MapCreaterSubWindow : EditorWindow
{
	// マップウィンドウのサイズ
	const float WINDOW_W = 750.0f;
	const float WINDOW_H = 750.0f;
	// マップのグリッド数
	private int mapSize = 0;
	// グリッドサイズ。親から値をもらう
	private float gridSize = 0.0f;
	// マップデータ
	private struct MAP
	{
		public string image;
		public GameObject obj;
		public float rad;
		public bool flip;
	};
	MAP[,] map; 
	// グリッドの四角
	private Rect[,] gridRect;
	// 親ウィンドウの参照を持つ
	private MapCreater parent;

	// サブウィンドウを開く
	public static MapCreaterSubWindow WillAppear(MapCreater _parent){
		MapCreaterSubWindow window = (MapCreaterSubWindow)EditorWindow.GetWindow(typeof(MapCreaterSubWindow) , false);
		window.Show();
		window.minSize = new Vector2(WINDOW_W ,WINDOW_H);
		window.SetParent (_parent);
		window.init ();
		return window;
	}
	
	private void SetParent(MapCreater _parent){
		parent = _parent;
	}

	// サブウィンドウの初期化
	public void init(){
		mapSize = parent.MapSize;
		gridSize = parent.GridSize;
		 
		// マップデータを初期化
		map = new MAP[mapSize, mapSize];
		for (int i = 0; i < mapSize; i++) {
			for (int j = 0; j < mapSize; j++) {
				map[i,j].image = "";
				map[i,j].obj = null;
				map[i, j].rad = 0;
				map[i, j].flip = false;
			}
		}
		// グリッドデータを生成
		gridRect = CreateGrid(mapSize);
	}



	void OnGUI(){
		// グリッド線を描画する
		for(int yy = 0 ; yy < mapSize ; yy++){
			for(int xx = 0 ; xx < mapSize ; xx++){
				DrawGridLine(gridRect[yy, xx]);
			}
		}

		Rect rect;

		// ステージ生成
		rect = new Rect(150, WINDOW_H - 100, 100, 50);
		GUILayout.BeginArea(rect);
		if (GUILayout.Button("ステージ生成", GUILayout.MinWidth(100), GUILayout.MinHeight(50)))
		{
			CreateStage();
		}
		GUILayout.EndArea();

		// グリッド全消去
		rect = new Rect(300, WINDOW_H - 100, 100, 50);
		GUILayout.BeginArea(rect);
		if (GUILayout.Button("グリッド全消去", GUILayout.MinWidth(100), GUILayout.MinHeight(50)))
		{
			DeleteAllGridStage();
		}
		GUILayout.EndArea();

		// ステージから輸入
		rect = new Rect(450, WINDOW_H - 100, 100, 50);
		GUILayout.BeginArea(rect);
		if (GUILayout.Button("ステージからコピー", GUILayout.MinWidth(100), GUILayout.MinHeight(50)))
		{
			Stage2Grid();
		}

		GUILayout.FlexibleSpace();
		GUILayout.EndArea();

		// →右クリックは消去
		// クリックされた位置を探して、その場所に画像データを入れる
		Event e = Event.current;
		if (e.type == EventType.ContextClick)
		// 右クリックの時はデータを消す
		{
			Vector2 pos = Event.current.mousePosition;
			int xx;
			// x位置を先に計算して、計算回数を減らす
			for (xx = 0; xx < mapSize; xx++)
			{
				Rect r = gridRect[0, xx];
				if (r.x <= pos.x && pos.x <= r.x + r.width)
				{
					break;
				}
			}

			// 後はy位置だけ探す
			for (int yy = 0; yy < mapSize; yy++)
			{
				if (gridRect[yy, xx].Contains(pos))
				{
					map[yy, xx].image = "";
					map[yy, xx].obj = null;
					map[yy, xx].rad = 0.0f;
					map[yy, xx].flip = false;
					Repaint();
					break;
				}
			}
		}
		else if (e.type == EventType.MouseDown){
			Vector2 pos = Event.current.mousePosition;
			int xx;
			// x位置を先に計算して、計算回数を減らす
			for(xx = 0 ; xx < mapSize ; xx++){
				Rect r = gridRect[0 ,xx];
				if(r.x <= pos.x && pos.x <= r.x + r.width){
					break;
				}
			}

			// 後はy位置だけ探す
			for(int yy = 0 ; yy < mapSize ; yy++){
				if(gridRect[yy,xx].Contains(pos)){
					map[yy, xx].image = parent.selectedInfoImage(map[yy, xx].image);
					map[yy, xx].obj = parent.selectedInfoObj(map[yy, xx].obj);
					map[yy, xx].rad = parent.selectedInfoRad(map[yy, xx].rad);
					map[yy, xx].flip = parent.selectedInfoFlip(map[yy, xx].flip);
					Repaint();
					break;
				}
			}
		}

        // 選択した画像を描画する
        for (int yy = 0 ; yy < mapSize ; yy++){
			for(int xx = 0 ; xx < mapSize ; xx++){
				if(map[yy,xx].image != null && map[yy,xx].image.Length > 0){

					GUIUtility.RotateAroundPivot(map[yy, xx].rad, new Vector2(gridRect[yy, xx].x + gridRect[yy, xx].width / 2.0f, gridRect[yy, xx].y + gridRect[yy, xx].height / 2.0f));

					Texture2D tex = (Texture2D)AssetDatabase.LoadAssetAtPath (map[yy,xx].image , typeof(Texture2D));
					GUI.DrawTexture(gridRect[yy,xx] , tex);
					GUI.matrix = Matrix4x4.identity;
				}
			}
		}
	}

	// グリッドデータを生成
	private Rect[,] CreateGrid(int div){
		int sizeW = div;
		int sizeH = div;

		float x = 0.0f;
		float y = 0.0f;
		float w = gridSize;
		float h = gridSize;

		Rect[,] resultRects = new Rect[sizeH ,sizeW];

		for(int yy = 0 ; yy < sizeH ; yy++){
			x = 0.0f;
			for(int xx = 0 ; xx < sizeW ; xx++){
				Rect r = new Rect(new Vector2(x , y) , new Vector2(w , h));
				resultRects[yy , xx] = r;
				x += w;
			}
			y += h;
		}

		return resultRects;
	}

	// グリッド線を描画
	private void DrawGridLine(Rect r){
		// grid
		Handles.color = parent.GridColor;

		// upper line
		Handles.DrawLine(
			new Vector2(r.position.x 			, r.position.y) , 
			new Vector2(r.position.x + r.size.x , r.position.y));

		// bottom line
		Handles.DrawLine(
			new Vector2(r.position.x 			, r.position.y + r.size.y) , 
			new Vector2(r.position.x + r.size.x , r.position.y + r.size.y));

		// left line
		Handles.DrawLine(
			new Vector2(r.position.x , r.position.y) , 
			new Vector2(r.position.x , r.position.y + r.size.y));

		// right line
		Handles.DrawLine(
			new Vector2(r.position.x + r.size.x , r.position.y) , 
			new Vector2(r.position.x + r.size.x , r.position.y + r.size.y));
	}

	// ファイルで出力
	private void OutputFile(){
		string path = parent.OutputFilePath();

		FileInfo fileInfo = new FileInfo(path);
		StreamWriter sw = fileInfo.AppendText();
		sw.WriteLine(GetMapStrFormat());
		sw.Flush();
		sw.Close();

		// 完了ポップアップ
		EditorUtility.DisplayDialog("MapCreater" , "output file success\n" + path , "ok");
	}

	// 出力するマップデータ整形
	private string GetMapStrFormat(){
		string result = "";
		for (int i = 0; i < mapSize; i++) {
			for(int j = 0 ; j < mapSize ; j++){
				result += OutputDataFormat(map[i,j].image);
				if(j < mapSize - 1){
					result += ",";
				}
			}
			result += "\n";
		}
		return result;
	}

	private string OutputDataFormat(string data){
		if(data != null && data.Length > 0){
			string[] tmps = data.Split('/');
			string fileName = tmps[tmps.Length - 1];
			return fileName.Split('.')[0];
		}else{
			return "";
		}
	}

	// ステージ生成
	private void CreateStage()
	{
		DeleteAllStage();

		Debug.Log("ステージ生成 : 場所" + parent.StageInstance);
		Vector2 firstPos = new Vector2(-352.0f , 352.0f);	// 左上 -352,352
		Vector2 ObjectPos = new Vector2(0.0f , 0.0f);   // 現在参照している位置
		Vector2 ObjectSize = new Vector2(64.0f, 64.0f); // オブジェクトのサイズ

		ObjectPos = firstPos;
		for (int x = 0; x < 12; ++x)
		{
			for (int y = 0; y < 12; ++y)
			{
				if (map[y, x].obj == null)
				{
					ObjectPos.y -= ObjectSize.y;
					continue;
				}

				// マップ生成
				Vector3 pos = new Vector3(ObjectPos.x, ObjectPos.y, parent.StageInstance.transform.position.z);
				Quaternion qua = Quaternion.identity;

				if(map[y, x].flip)
				{
					qua = Quaternion.Euler(new Vector3(0, 180, map[y, x].rad * -1.0f));
				}
				else
				{
					qua = Quaternion.Euler(new Vector3(0, 0, map[y, x].rad * -1.0f));
				}

				GameObject.Instantiate(map[y, x].obj , pos, qua, parent.StageInstance.transform).name = map[y, x].obj.name;

				ObjectPos.y -= ObjectSize.y;

			}
			ObjectPos.y = firstPos.y;
			ObjectPos.x += ObjectSize.x;
		}
	}

	// ステージ全消去
	private void DeleteAllStage()
	{
		int i = parent.StageInstance.transform.childCount;
		int c = 0;
		int cntFor = i / 2 + 1;
		for(int n = 0; n < cntFor; ++n)
		{
			foreach (Transform child in parent.StageInstance.transform)
			{
				++c;
				GameObject.DestroyImmediate(child.gameObject);
			}
		}
		Debug.Log("消した数 : " + c.ToString() + " : 子供の数 : " + i.ToString());
	}

	// グリッドステージ全消去
	private void DeleteAllGridStage()
	{
		for (int x = 0; x < 12; ++x)
		{
			for (int y = 0; y < 12; ++y)
			{
				map[y, x].image = "";
				map[y, x].obj = null;
			}
		}
	}

	// ステージから輸入
	private void Stage2Grid()
	{
		// ステージ座標からグリッド座標計算
		int i = parent.StageInstance.transform.childCount;
		int c = 0;
		int cntFor = i / 2 + 1;
		for (int n = 0; n < cntFor; ++n)
		{
			foreach (Transform child in parent.StageInstance.transform)
			{
				Vector3 pos = child.position;

				// xを求める
				pos.x += 32 + 64 * 5;
				int x = (int)pos.x / 64;
				// yを求める
				pos.y += 32 + 64 * 5;
				int y = (int)pos.y / 64;

				// オブジェクトの名前からイメージ検索
				MapCreater.IMAGE_PATH[] obj = parent.ObjectCount();
				for (int p = 0; p < obj.Length; ++p)
				{
					if (obj[p].selectedImageObjects == null)
					{
						continue;
					}

					if (child.name == obj[p].selectedImageObjects.name)
					{
						map[11-y, x].image = obj[p].selectedImagePaths;
						map[11-y, x].obj = obj[p].selectedImageObjects;
						map[11-y, x].rad = child.transform.rotation.eulerAngles.z * -1.0f;
					}
				}

			}
		}
	}

}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class temperatureController : MonoBehaviour {
    public enum WaterState
    {
        WATER = 0,
        STEAM,
        MAX
    }

    [SerializeField]
    [Tooltip("水蒸気テクスチャ")]
    private Sprite steamTexture;
    [SerializeField]
    [Tooltip("水テクスチャ")]
    private Sprite waterTexture;
    [SerializeField]
    [Tooltip("温度")]
    private float temperature;      //温度
    [SerializeField]
    [Tooltip("最高温度")]
    private float topTemperature;   //最高温度
    [SerializeField]
    [Tooltip("最低温度")]
    private float lowTemperature;   //最低温度
    [SerializeField]
    [Tooltip("変動値")]
    [Range(0.0f, 1000.0f)]
    private float variable;         //変動値
    [SerializeField]
    [Tooltip("沸点")]
    private float boilingPoint;     //沸点
    [SerializeField]
    [Tooltip("液化点")]
    private float liquefaction;     //液化点
    [SerializeField]
    [Tooltip("浮く力")]
    [Range(0.0f, 100.0f)]
    private float floatPower;       //浮く力
    [SerializeField]
    [Tooltip("水蒸気になっている時間")]
    private int steamTimer;

	private Rigidbody2D myRigidbody;    //自分のリジッドボディー
    private SpriteRenderer mySpriteRenderer;        //自分のスプライトレンダラー
    private WaterState myState;     //自分の状態

    public float Temperature
    {
        set { temperature = value; }
        get { return temperature; }
    }

	public WaterState State { get { return myState; } }

    private void Start()
    {
        mySpriteRenderer = GetComponent<SpriteRenderer>();
        myRigidbody = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        temperature -= variable;

        //上限下限
        if (lowTemperature > temperature)
            temperature = lowTemperature;
        if (topTemperature < temperature)
            temperature = topTemperature;

        //状態変化
        if (boilingPoint < temperature && myState == WaterState.WATER)
        {
            myState = WaterState.STEAM;
            mySpriteRenderer.sprite = steamTexture;
            myRigidbody.gravityScale = -floatPower;
        }

        if (liquefaction > temperature && myState == WaterState.STEAM)
        {
            myState = WaterState.WATER;
            mySpriteRenderer.sprite = waterTexture;
            myRigidbody.gravityScale = 1.0f;
        }   
    }
}
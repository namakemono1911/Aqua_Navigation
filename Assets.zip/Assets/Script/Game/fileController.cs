﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fileController : MonoBehaviour {
    [SerializeField]
    [Tooltip("温度")]
    [Range(0.0f, 1000.0f)]
    private float temperature;

    private void OnTriggerStay2D(Collider2D collision)
    {
		if (this.GetComponent<startFlagManager>().GetStartFlag() == false)
		{
			return;
		}

		if (collision.tag != "transer")
            return;

		Debug.Log("fire");
        var script = collision.GetComponent<temperatureController>();
        script.Temperature += temperature;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class viewMission : MonoBehaviour {

	[SerializeField]
	private CanvasGroup missions;

	private void OnTriggerEnter2D(Collider2D collision)
	{
		if(collision.tag == "mouse")
		{
			missions.alpha = 1;
			missions.blocksRaycasts = true;
		}
	}

	private void OnTriggerExit2D(Collider2D collision)
	{
		if (collision.tag == "mouse")
		{
			missions.alpha = 0.5f;
			missions.blocksRaycasts = false;
		}
	}
}

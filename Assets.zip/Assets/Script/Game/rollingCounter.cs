﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rollingCounter : MonoBehaviour {

    private int rollCount;

	// Use this for initialization
	void Start () {
        rollCount = 0;
        rollCount = this.transform.childCount;
    }
	
	// Update is called once per frame
	void Update () {
        rollCount = this.transform.childCount;
        Debug.Log("残っている弾の数 : " + rollCount);
	}

    public int rollNum()
    {
        return rollCount;
    }
}

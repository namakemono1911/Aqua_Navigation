﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class angleAdjustment : MonoBehaviour {

    [SerializeField]
    private float rotationSpeed;

    [SerializeField]
    private Transform midpoint;

	[SerializeField, Tooltip("バケツたち")]
	private GameObject[] baketus;

	// Use this for initialization
	void Start ()
    {
	}

    // Update is called once per frame
    void Update ()
    {
		if (this.transform.parent.GetComponent<startFlagManager>().GetStartFlag() == false)
			return;

        midpoint.Rotate(new Vector3(0, 0, rotationSpeed));

		// バケツにrigitbody
		for(int i = 0; i < baketus.Length;++i)
		{
			Rigidbody2D rigit = baketus[i].transform.GetComponent<Rigidbody2D>();
			rigit.simulated = true;
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseInfo : MonoBehaviour {
    [SerializeField]
    public mouseContller mouseControllerSC;
}

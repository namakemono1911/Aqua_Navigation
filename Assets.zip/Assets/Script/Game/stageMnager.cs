﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageMnager : MonoBehaviour {

    [SerializeField]
    private GameObject[] stage; // ステージ材料
    [SerializeField]
    private int maxStage;   // そのステージに置ける最大数
    [SerializeField]
    private mouseContller mouse;

    private GameObject[] stageObjects;  // 動的生成
    private int cntStage;   // 現在のステージオジェクト数
	// Use this for initialization
	void Start () {
        cntStage = 0;
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SetStage1() {
        if (stage.Length >= maxStage || stage[0] == null)
        {
            Debug.Log("ステージにこれ以上おけません");
        }

        stageObjects[cntStage] = GameObject.Instantiate(stage[0]);
        Vector3 pos = mouse.GetMousePos();
        stageObjects[cntStage].transform.position = new Vector3(pos.x , pos.y , pos.z);
        int aa = 0;
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageObjectManager : MonoBehaviour {

	[SerializeField, Tooltip("ステージ地面生成場所")]
	private GameObject stageInstanceSpace;
    private int stageNum;

	// Use this for initialization
	void Start () {
        stageNum = 0;
    }

    // Update is called once per frame
    void Update () {
		
	}

    public void CheckStageObj()
    {
        stageNum = 0;
        Transform tr = this.GetComponent<Transform>();
        foreach (Transform child in tr)
        {
            if (child.tag != "stageEditor")
                continue;

            ++stageNum;
        }
    }

    public int GetStageObject()
    {
        return stageNum;
    }

	public GameObject GetStageInstanceSpace()
	{
		return stageInstanceSpace;
	}
}

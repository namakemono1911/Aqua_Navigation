﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[System.Serializable]
public class RULE
{
    public enum RULE_TYPE
    {
        RULE_1 = 0,
        RULE_2,
        RULE_MAX
    };

    [SerializeField, TooltipAttribute("ルール \n RULE_1 : 配置オブジェクトn個以下\n RULE_2 : n個以上ゴール\n RULE_3 : 1個もロスしてはいけない\n RULE_MAX : ルール無し")]
    RULE_TYPE rule;
    [SerializeField]
    int num;

    bool success;   // 成功判定

	public bool Success { set { success = value; } get { return success; } }

    public void OnSuccess()
    {
        success = true;
    }

    public void offSuccess()
    {
        success = false;
    }

    public bool GetSuccess() {
        return success;
    }

    public RULE_TYPE GetRuleType()
    {
        return rule;
    }

    public int GetNum()
    {
        return num;
    }

}

public class ruleManager : MonoBehaviour {

    [SerializeField , Tooltip("ユーザーが置く場所")]
    private GameObject stageObjectSpaceUser;  // どこに入ってるか
	[SerializeField, Tooltip("開発者が置く場所")]
	private GameObject stageObjectSpace;  // どこに入ってるか
	[SerializeField]
    public RULE[] rules;
    [SerializeField]
    private stageObjectManager stageObject;
    [SerializeField]
    private goal goalObject;
    [SerializeField]
    private ballInstanser ballInstansSpace;
	[SerializeField]
	private ResultManager result;
    private bool gameRunning;   // ゲームがスタート状態か
	private mouseContller mousePos;
	[SerializeField]
	private missionStarController missionStars;
	[SerializeField]
	private ImageManager resultImageMamanger;
	[SerializeField]
	private leftUIController Escape;
	private bool resultStart;
	[SerializeField,Tooltip("ルールの番号")]
	private int[] ruleNumber;

	struct STAGE
	{
		public string name;
		public Vector3 pos;
		public Quaternion rot;
		public remainingNumberController button;
	};

	private STAGE[] stages;    // start時のステージ床情報
	private STAGE[] stageObjects;   // start時のオブジェクト情報

	private dataManager.Data scoreData;
	private dataManager dataManager;
	private int stageNum;
    // Use this for initialization
    void Start () {



		stageNum = SceneManager.GetActiveScene().buildIndex;
		dataManager = this.GetComponent<dataManager>();
		scoreData = dataManager.LoadData(scoreData, stageNum);


		/////////////////////////////////////////////////////////////////////////////
		// ルール全て読み込んで。
		rules[0].Success = scoreData.mission1;
		rules[1].Success = scoreData.mission2;
		missionStars.SetColor(rules[0].Success, rules[1].Success);

		/////////////////////////////////////////////////////////////////////////////

		resultStart = false;

		// 床情報格納
		// スタート&ゴール格納
		int cntChild = stageObjectSpace.transform.childCount;
		stages = new STAGE[cntChild];	// 子供分生成
		for (int i = 0; i < cntChild; ++i)
		{
			GameObject child = stageObjectSpace.transform.GetChild(i).gameObject;
			stages[i].name = child.name;
			stages[i].pos = child.transform.position;
			stages[i].rot = child.transform.rotation;

			if (child.tag == "startObject")
			{
				ballInstansSpace = child.GetComponent<ballInstanser>();
				Debug.Log("start");
			}
			else if (child.tag == "goalObject")
			{
				goalObject = child.GetComponent<goal>();
				Debug.Log("goal");
			}

		}

		// マウス格納
		mousePos = stageObjectSpaceUser.transform.GetChild(0).GetComponent<mouseContller>();

	}
	
	// Update is called once per frame
	void Update () {
	}

    public void start()
    {
		if(Escape.GetEscape() == true)
		{
			Debug.Log("ポーズ中 : start");
			return;
		}

		gameStart();

		// 各自スタート関数
		Debug.Log("ゲームスタート");

        // 子供検索→スタート、情報保持
        Transform tr = stageObjectSpaceUser.GetComponent<Transform>();
		int cntChild = stageObjectSpaceUser.transform.childCount;
		stageObjects = new STAGE[cntChild - 1];
		for (int i = 1; i< cntChild;++i)
		{
			GameObject child = stageObjectSpaceUser.transform.GetChild(i).gameObject;

			child.GetComponent<startFlagManager>().OnStart();
			Debug.Log("chilt name : " + child.name.ToString());

			// start時のオブジェクト情報保持
			stageObjects[i - 1].name = child.name;
			stageObjects[i - 1].pos = child.transform.position;
			stageObjects[i - 1].rot = child.transform.rotation;
			stageObjects[i - 1].button = child.transform.GetComponent<stageGridEditor>().getButton();
		}

		// スタート&ゴール格納
		cntChild = stageObjectSpace.transform.childCount;
		for (int i = 0; i < cntChild; ++i)
		{
			GameObject child = stageObjectSpace.transform.GetChild(i).gameObject;

			if (child.tag != "stageEditor")
				continue;

			child.GetComponent<startFlagManager>().OnStart();
		}

	}

	// 達成数を返す , 1桁目 : 1つ目の合否
	public int GetSuccessNum()
    {
        int success = 0;

        for (int i = 0; i < rules.Length; ++i)
        {
            if (!rules[i].GetSuccess())
            {
                continue;
            }

            success += 1 * MathPower(10 , i);
        }

        return success;
    }

    // iのq乗を返す
    public int MathPower(int i, int q)
    {
        int math = 1;
        for (int u = 0; u < q; ++u)
        {
            math *= i;
        }
        return math;
    }

    // ルールの達成の判定
    public bool[] SeeRuleSuccess(bool[] stars)
    {
        for (int i = 0; i < rules.Length; i++)
        {
            switch (rules[i].GetRuleType())
            {
                case RULE.RULE_TYPE.RULE_1: // オブジェクトn個以下

					if(CheckRule1(rules[i].GetNum()) && stars[0])
					{
						stars[i] = CheckRule1(rules[i].GetNum());
					}
					else
					{
						stars[i] = false;
					}
					break;
                case RULE.RULE_TYPE.RULE_2: // n個以上ゴール
					stars[i] = CheckRule2(rules[i].GetNum());
					break;
            }
        }

		return stars;

	}

    // ステージオブジェクトの個数がn個以下
    public bool CheckRule1(int n)
    {
        int nObj = stageObjects.Length;
        if (n >= nObj)
        {
            return true;
        }
        return false;
    }

    // n個以上ゴール
    public bool CheckRule2(int n)
    {
        int nObj = goalObject.GetGoalNum();
        if (n <= nObj)
        {
            return true;
        }
        return false;
    }

    // 1つも落とさずゴール
    public bool checkRule3()
    {
        if (goalObject.GetGoalNum() < ballInstansSpace.GetBallNumStart())
        {
            return false;
        }
        return true;
    }

    // ゲームの状態を取得
    public bool GetGameRunnning()
    {
        return gameRunning;
    }


	// リスタート -オブジェクト、床、水全回復-
	public void Retry()
	{
		if (Escape.GetEscape() == true || resultStart == true)
		{
			Debug.Log("ポーズ中 : retury");
			return;
		}

		gameStop();

		gameRunning = false;
		// 床、水
		Transform[] gm = stageObjectSpace.GetComponentsInChildren<Transform>();
		for (int i = 1; i < gm.Length; ++i)
		{
			Destroy(gm[i].gameObject);
		}

		for (int i = 0; i<stages.Length;++i)
		{
			Debug.Log(i.ToString() + "番目 : " + stages[i].name);

			GameObject gmobj = GameObject.Instantiate(Resources.Load("Prefub/" + stages[i].name) as GameObject, stages[i].pos, stages[i].rot, stageObjectSpace.transform);
			gmobj.name = stages[i].name;
			// スタートorゴール
			if (gmobj.tag == "startObject")
			{
				ballInstansSpace = gmobj.GetComponent<ballInstanser>();
			}
			else if (gmobj.tag == "goalObject")
			{
				goalObject = gmobj.GetComponent<goal>();
			}
			else if(gmobj.tag == "stageEditor")
			{
				gmobj.GetComponent<startFlagManager>().OffStart();
			}
		}

		// オブジェクト
		DeleteAllObjects2();

		for (int i = 0; i < stageObjects.Length; ++i)
		{
			GameObject mg;
			mg = GameObject.Instantiate(Resources.Load("Prefub/stage/" + stageObjects[i].name) as GameObject, stageObjects[i].pos,
				stageObjects[i].rot, stageObjectSpaceUser.transform);

			mg.name = stageObjects[i].name;

			mg.GetComponent<startFlagManager>().OffStart();
			// マウス追従解除
			mg.GetComponent<stageGridEditor>().nonMove();
			// マウス入れる
			mg.GetComponent<stageGridEditor>().SetMouseScript(this.mousePos);
			// スタンプをnull
			mg.GetComponent<stageGridEditor>().nonStanp();
			// ボタン連動引継ぎ
			mg.GetComponent<stageGridEditor>().setButton(stageObjects[i].button);


		}
	}

	// デリート全てのオブジェクト
	public void DeleteAllObjects()
	{
		if (Escape.GetEscape() == true || resultStart == true)
		{
			Debug.Log("ポーズ中 : deleteAllObjects");
			return;
		}

		int cntChild = stageObjectSpaceUser.transform.childCount;
		for(int i = 1; i < cntChild; ++i)
		{
			Destroy(stageObjectSpaceUser.transform.GetChild(i).gameObject);
		}

		/////////////////////////////
		//全てのuiにも干渉
		var content = GameObject.Find("Content");
		for (int i = 0; i < content.transform.childCount; i++)
			content.transform.GetChild(i).GetComponent<remainingNumberController>().resetRemaining();
		/////////////////////////////
	}

	// デリート全てのオブジェクト
	public void DeleteAllObjects2()
	{
		int cntChild = stageObjectSpaceUser.transform.childCount;
		for (int i = 1; i < cntChild; ++i)
		{
			Destroy(stageObjectSpaceUser.transform.GetChild(i).gameObject);
		}
	}


	public void gameStart()
	{
		if (Escape.GetEscape() == true || resultStart == true)
		{
			Debug.Log("ポーズ中 : gameStart");
			return;
		}

		gameRunning = true;
	}

	public void gameStop()
	{
		if (Escape.GetEscape() == true || resultStart == true)
		{
			Debug.Log("ポーズ中 : gameStop");
			return;
		}
		gameRunning = false;
	}

	public void Measurement()
	{

		if (Escape.GetEscape() == true || resultStart == true)
		{
			Debug.Log("ポーズ中 : Measurement");
			return;
		}

		Debug.Log("ゲーム終了");

		// ルール判定
		bool[] stars = new bool[3];
		stars[0] = false;
		stars[1] = false;
		gameRunning = false;

		resultStart = true;
		SeeRuleSuccess(stars);
		missionStars.SetColor(stars[0], stars[1]);
		for (int i = 0; i < 3; ++i)
		{
			resultImageMamanger.SetViewStar(i, stars[i]);
		}

		// ゲームクリア―
		SetRule();

		if(stars[0] == true)
		{
			resultImageMamanger.SetGameState(true);
		}
		else
		{
			resultImageMamanger.SetGameState(false);
		}

		result.Result_DrawOn();

		//////////////////////////////////////////////////////////////////
		// データの処理
		int score = getNumGoalBall();   // スコア
		// ハイスコア
		if (score > scoreData.highScore)
		{
			scoreData.highScore = score;
		}
		// ミッション
		scoreData.mission1 = stars[0];
		scoreData.mission2 = stars[1];
		// セーブ
		dataManager.SaveData(scoreData, stageNum);
		//////////////////////////////////////////////////////////////////

	}

	public void saveNow()
	{
		dataManager.SaveData(scoreData, stageNum);
	}

	public int getNumBall()
	{
		if (ballInstansSpace == null)
		{
			return 0;
		}

		return ballInstansSpace.GetBallNumStart() - ballInstansSpace.GetBallDelete();
	}

	public int getNumStartBall()
	{
		if(ballInstansSpace == null)
		{
			return 0;
		}

		return ballInstansSpace.GetBallNumStart();
	}

	public int getNumGoalBall()
	{
		if (ballInstansSpace == null)
		{
			return 0;
		}
		return goalObject.GetGoalNum();
	}

	public int getNumHighScore()
	{
		if (ballInstansSpace == null)
		{
			return 0;
		}

		if(scoreData.highScore <= getNumGoalBall())
		{
			return getNumGoalBall();
		}

		return scoreData.highScore;
	}

	public int getDataHighScore()
	{
		return scoreData.highScore;
	}


	private void SetRule()
	{
		resultImageMamanger.SetRule(ruleNumber[0], ruleNumber[1]);
	}

	public bool isResult()
	{
		return resultStart;
	}

}


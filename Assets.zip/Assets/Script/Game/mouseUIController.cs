﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseUIController : MonoBehaviour {

	[SerializeField]
	private CanvasGroup mouseui1;
	[SerializeField]
	private CanvasGroup mouseui2;
	[SerializeField]
	private mouseContller mouse;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		// マウスが何か持っていたら
		if(mouse.DoYouHaveAnyObject())
		{
			mouseui1.alpha = 1;
			mouseui1.blocksRaycasts = true;
			mouseui2.alpha = 0;
			mouseui2.blocksRaycasts = false;
		}
		else
		{
			mouseui2.alpha = 1;
			mouseui2.blocksRaycasts = true;
			mouseui1.alpha = 0;
			mouseui1.blocksRaycasts = false;
		}
	}
}

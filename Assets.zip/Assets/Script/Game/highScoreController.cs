﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class highScoreController : MonoBehaviour {
    private ruleManager rule;
    private remainingNumberController numController;

	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {

		rule = GameObject.Find("RuleManager").GetComponent<ruleManager>();
		if(rule.isResult())
		{
			numController = GetComponent<remainingNumberController>();
			numController.Remaining = rule.getNumHighScore();
			numController.RemainingIndex = rule.getNumHighScore();
		}
		else
		{
			numController = GetComponent<remainingNumberController>();
			numController.Remaining = rule.getDataHighScore();
			numController.RemainingIndex = rule.getDataHighScore();
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageObjectController : MonoBehaviour {

    [SerializeField]
    private mouseContller mouse;

    private bool mouseHit;  // マウスで移動できる状態


	// Use this for initialization
	void Start () {
        mouseHit = false;
    }
	
	// Update is called once per frame
	void Update () {
        if (mouseHit == true) {
            Vector3 pos = mouse.GetMousePos();
            this.gameObject.transform.position = new Vector3(pos.x, pos.y, 0);
        }
        else {
        }
	}

    private void OnTriggerStay2D(Collider2D collision)
    {
        // マウスなら
        if (collision.gameObject.tag == "mouse" && Input.GetMouseButtonDown(0))
        {
            // 追従状態開始
            if (mouseHit == false)
            {
                Debug.Log("true");
                mouseHit = true;
            }
            else {
                Debug.Log("false");
                mouseHit = false;
            }
        }
    }

}

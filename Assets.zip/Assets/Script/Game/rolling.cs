﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rolling : MonoBehaviour
{
	[SerializeField]
	private temperatureController state;

	// Use this for initialization
	void Start()
    {
	}

    // Update is called once per frame
    void Update()
    {
		// 画面外
		if(this.transform.position.y <= -545)
		{
			if(this.tag != "doro")
			{
				this.transform.parent.parent.GetComponent<ballInstanser>().AddBallDelete();
			}

			Destroy(this.gameObject);
		}
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
		if (this.tag == "doro")
			return;

			if (state.State == temperatureController.WaterState.STEAM)
			return;

		stageMiniObjectInstanser stage = collision.transform.gameObject.GetComponent<stageMiniObjectInstanser>();

		if (stage != null && this.tag == "transer")
		{
			stage.SubLife();
		}

		if (collision.transform.tag == "stageDelete" && this.tag == "transer")
        {
			this.transform.parent.parent.GetComponent<ballInstanser>().AddBallDelete();
			Destroy(this.gameObject);
        }
    }
}
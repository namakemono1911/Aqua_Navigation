﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class returnStageSelect : MonoBehaviour {

    public void GoStageSelect()
    {
        FadeManager.FadeOut(1);
    }
}

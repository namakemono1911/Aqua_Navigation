﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class limitLength : MonoBehaviour {

	[SerializeField,Tooltip("x:地面までの距離で離れていたい距離\ny:地面までの距離でこれ以上離れたくない距離")]
	private Vector2 length;
	//[SerializeField, Tooltip("横")]
	private float  width;
	private GameObject stageInstanceSpace;
	private GameObject stageObject;
	[SerializeField, Tooltip("BoxCollider2D")]
	private BoxCollider2D size;
	[SerializeField, Tooltip("取り入れるタグ")]
	private string[] tags;
	private bool path;  // おけるか置けないか
	private Vector3 scale;

	[SerializeField]
	private bool side;
	[SerializeField]
	private Vector3 offset;
	[SerializeField]
	private bool title;
	// Use this for initialization
	void Start () {
		path = false;
		scale = this.transform.localScale;
		width = 32;
	}
	
	// Update is called once per frame
	void Update () {

		if(title == true)
		{
			return;
		}

		if(side == false)
		{
			// 物体から下に直線を伸ばし、lengthより短いところで当たっていたら置ける
			stageObjectManager a = this.transform.parent.GetComponent<stageObjectManager>();

			if(a == null)
			{
				return;
			}

			stageInstanceSpace = this.transform.parent.GetComponent<stageObjectManager>().GetStageInstanceSpace();
			Transform[] tr = stageInstanceSpace.GetComponentsInChildren<Transform>();
			Vector3 pos = this.transform.position;
			path = false;
			foreach (Transform child in tr)
			{
				if (matchTags(child.tag))
				{
					continue;
				}

				// 自分とxが同じ＆＆真下
				if (pos.x + width / 2.0f > child.position.x && pos.x - width / 2.0f < child.position.x &&
					pos.y - length.x > child.position.y && pos.y - length.y < child.position.y)
				{
					Debug.Log("path = true");
					path = true;
					break;
				}
			}

			// もともとオブジェクトが置いてある or もともと地面が置いてある
			// →置けない
			// 地面
			for (int i = 1; i < tr.Length; ++i)
			{
				if (pos.x + width / 2.0f > tr[i].position.x && pos.x - width / 2.0f < tr[i].position.x &&
					pos.y + length.x > tr[i].position.y && pos.y - length.x < tr[i].position.y)
				{
					Debug.Log("Stagepath = false");
					path = false;
					break;
				}
			}

			// オブジェクト
			stageObject = this.transform.parent.gameObject;
			tr = stageObject.GetComponentsInChildren<Transform>();

			foreach (Transform child in tr)
			{
				// stageEditor以外はcontinue
				if (child.tag != "stageEditor")
					continue;

				// 自分は避ける
				if (child.gameObject == this.gameObject)
					continue;

				// 自分とxが同じ＆＆真ん中
				if (pos.x + width / 2.0f > child.position.x && pos.x - width / 2.0f < child.position.x &&
					pos.y + length.x > child.position.y && pos.y - length.x < child.position.y)
				{
					Debug.Log("Objectpath = false");
					path = false;
					break;
				}
			}
		}
		else
		{
			// 物体から下に直線を伸ばし、lengthより短いところで当たっていたら置ける
			stageInstanceSpace = this.transform.parent.GetComponent<stageObjectManager>().GetStageInstanceSpace();
			Transform[] tr = stageInstanceSpace.GetComponentsInChildren<Transform>();

			Vector3 rot = this.transform.localEulerAngles;


			Vector3 pos = this.transform.position;

			if (rot.y > 90)
			{
				pos -= offset;
			}
			else
			{
				pos += offset;
			}

			path = false;
			foreach (Transform child in tr)
			{
				if (matchTags(child.tag))
				{
					continue;
				}

				// 自分とxが同じ＆＆真下
				if (pos.x + width / 2.0f > child.position.x && pos.x - width / 2.0f < child.position.x &&
					pos.y - length.x > child.position.y && pos.y - length.y < child.position.y)
				{
					Debug.Log("path = true");
					path = true;
					break;
				}
			}

			// もともとオブジェクトが置いてある or もともと地面が置いてある
			// →置けない
			// 地面
			for (int i = 1; i < tr.Length; ++i)
			{
				if (pos.x + width / 2.0f > tr[i].position.x && pos.x - width / 2.0f < tr[i].position.x &&
					pos.y + length.x > tr[i].position.y && pos.y - length.x < tr[i].position.y)
				{
					Debug.Log("Stagepath = false");
					path = false;
					break;
				}
			}

			// オブジェクト
			stageObject = this.transform.parent.gameObject;
			tr = stageObject.GetComponentsInChildren<Transform>();

			foreach (Transform child in tr)
			{
				// stageEditor以外はcontinue
				if (child.tag != "stageEditor")
					continue;

				// 自分は避ける
				if (child.gameObject == this.gameObject)
					continue;

				// 自分とxが同じ＆＆真ん中
				if (pos.x + width / 2.0f > child.position.x && pos.x - width / 2.0f < child.position.x &&
					pos.y + length.x > child.position.y && pos.y - length.x < child.position.y)
				{
					Debug.Log("Objectpath = false");
					path = false;
					break;
				}
			}
		}

	}

	public bool isPath()
	{
		return path;
	}

	private bool matchTags(string tag)
	{
		bool bTag = false;

		for(int i = 0; i < tags.Length; ++i)
		{
			if(tags[i] == tag)
			{
				bTag = true;
				break;
			}
		}

		// 一致していなかったらtrueを返す
		if (bTag)
			return false;

		return true;
	}
}

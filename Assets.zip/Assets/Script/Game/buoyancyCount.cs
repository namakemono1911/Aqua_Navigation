﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buoyancyCount : MonoBehaviour {
    [SerializeField]
    private BuoyancyEffector2D effect;
    [SerializeField]
    private float surfaceParcent;

    private int numBall = 0;
    public int NumBall
    {
        get { return numBall; }
    }

    private void FixedUpdate()
    {
        effect.surfaceLevel = numBall * surfaceParcent;
        numBall = 0;
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag != "transer")
            return;

        numBall++;
    }
}

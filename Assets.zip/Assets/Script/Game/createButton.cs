﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class createButton : MonoBehaviour {
    [SerializeField]
    private GameObject createObject;
    private GameObject imageUI;
    private Transform canvas;
    private remainingNumberController remainingNumberScript;
    private mouseContller mouseControllerScript;
    private ruleManager rule;

    public GameObject CreateObject
    {
        get { return createObject; }
        set { createObject = value; }
    }

	// Use this for initialization
	void Start ()
    {
        //残量制御スクリプト取得
        remainingNumberScript = GetComponent<remainingNumberController>();

        Transform parent = this.transform.parent;
        for ( ; parent.name.Equals("Content") == false ; )
            parent = parent.transform.parent;

        mouseControllerScript = parent.GetComponent<mouseInfo>().mouseControllerSC;

        canvas = GameObject.Find("Canvas").transform;
        rule = GameObject.Find("RuleManager").GetComponent<ruleManager>();
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void create ()
    {
        //残り0以下だったら終了
        if (0 >= remainingNumberScript.RemainingIndex)
            return;

        //スタートボタンが押されてたら終了
        if (rule.GetGameRunnning())
            return;

        if (mouseControllerScript.GetIsMouseObjectHavingAnything() == true)
            return;
        
        //マウス座標に生成
        Vector3 mousePos = Input.mousePosition;
        Vector3 screenToWorldPointPosition = Camera.main.ScreenToWorldPoint(mousePos);
        mousePos = screenToWorldPointPosition;
        mousePos += canvas.transform.position;
        mousePos.z = 0;

        GameObject gm = Instantiate(createObject, mousePos, new Quaternion(0.0f, 0.0f, 0.0f, 0.0f), mouseControllerScript.transform.parent);
        gm.GetComponent<stageGridEditor>().SetMouseScript(mouseControllerScript);
		gm.name = createObject.name;
		gm.GetComponent<stageGridEditor>().setButton(this.GetComponent<remainingNumberController>());
		Debug.Log("OK");

        //remainingNumberScript.RemainingIndex -= 1;
    }
}

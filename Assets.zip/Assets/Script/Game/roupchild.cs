﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class roupchild : MonoBehaviour {

	private roupScript parent;

	// Use this for initialization
	void Start () {
		parent = this.transform.GetComponent<roupScript>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
		if(collision.transform.tag == "watorOrigin")
		{
			parent.AddNumBall();
		}
	}


	private void OnTriggerEnter2D(Collider2D collision)
	{
		if (collision.transform.tag == "watorOrigin")
		{
			parent.AddNumBall();
		}
	}


	private void OnCollisionExit2D(Collision2D collision)
	{
		if (collision.transform.tag == "watorOrigin")
		{
			parent.AddNumBall(true);
		}
	}

	private void OnTriggerExit2D(Collider2D collision)
	{
		if (collision.transform.tag == "watorOrigin")
		{
			parent.AddNumBall(true);
		}
	}
}

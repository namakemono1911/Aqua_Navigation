﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class debug_ballInstans : MonoBehaviour {

    [SerializeField]
    private GameObject instans; // 生成するもの
    [SerializeField]
    private Vector2 moveSpeed;  // 移動スピード
    [SerializeField]
    private GameObject instansSpece;  // 生成する場所
	// Use this for initialization
	void Start () {
        if (!instans)
            Debug.Log("debug_ballInstans : No Gameobject");
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.Space))
        {
            SetInstans();
        }

        if (Input.GetKey(KeyCode.A))
        {
            AddPos(moveSpeed.x * -1, 0);
        }
        if (Input.GetKey(KeyCode.D))
        {
            AddPos(moveSpeed.x, 0);
        }
        if (Input.GetKey(KeyCode.W))
        {
            AddPos(0, moveSpeed.y);
        }
        if (Input.GetKey(KeyCode.S))
        {
            AddPos(0, moveSpeed.y * -1);
        }
    }

    private void SetInstans()
    {
        Instantiate(instans, this.transform.position,Quaternion.identity,instansSpece.transform);
    }

    private void AddPos(float x, float y)
    {
        Vector3 a = this.transform.position;
        a.x += x;
        a.y += y;
        this.transform.position = new Vector3(a.x, a.y, a.z);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class goal : MonoBehaviour {

    [SerializeField]
    private int goalMax;    // ゴールとなっている数
    private int goalNum;    // ゴールしている数
    private bool goalNow;  // ture ゴール : false 未ゴール

	[SerializeField]
	GameObject ballInstanceSpace;

    // Use this for initialization
    void Start() {
        goalNow = false;
        goalNum = 0;

		int cntChild = this.transform.parent.childCount;

		for(int i = 0; i < cntChild;++i)
		{
			Transform child = this.transform.parent.GetChild(i);
			if (child.tag == "startObject")
			{
				int nc = child.childCount;
				for(int j = 0; j < nc; ++j)
				{
					Transform cuson = child.GetChild(j);
					if(cuson.tag == "ballInstanceSpace")
					{
						ballInstanceSpace = cuson.gameObject;

						Debug.Log("ボールインスタンス : " + cuson.name.ToString());

					}
				}
			}
		}

    }

    // Update is called once per frame
    void Update() {
        if (goalNum >= goalMax)
        {
            goalNow = true;
        }

        Debug.Log("弾の数 : " + goalNum);

		// 弾の数を数える
		//int cntChild = ballInstanceSpace.transform.childCount;
		//Vector3 mine = this.transform.position;
		//goalNum = 0;
		//for (int i = 0; i < cntChild;++i)
		//{
		//	Transform child = ballInstanceSpace.transform.GetChild(i);
		//	Vector3 pos = child.position;
		//	if(mine.x - 32 >= pos.x && mine.x + 32 <= pos.x &&
		//		mine.y - 32 >= pos.y && mine.y + 32 <= pos.y)
		//	{
		//		++goalNum;
		//	}

		//}

	}

    public bool isGoal()
    {
        return goalNow;
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if (collision.tag == "transer")
    //    {
    //        ++goalNum;
    //    }
    //}

    public int GetGoalNum() {

		int cntChild = ballInstanceSpace.transform.childCount;
		Vector3 mine = this.transform.position;
		goalNum = 0;
		for (int i = 0; i < cntChild; ++i)
		{
			Transform child = ballInstanceSpace.transform.GetChild(i);
			Vector3 pos = child.position;
			if (mine.x - 32 <= pos.x && mine.x + 32 >= pos.x &&
				mine.y - 32 <= pos.y && mine.y + 32 >= pos.y)
			{
				++goalNum;
			}

		}

		return goalNum;
    }
}
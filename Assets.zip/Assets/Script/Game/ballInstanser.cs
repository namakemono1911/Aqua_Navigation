﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballInstanser : MonoBehaviour {

    [SerializeField, Tooltip("生成するオブジェクト")]
    private GameObject ball;
    [SerializeField, Tooltip("生成数")]
    private int num;
    [SerializeField , TooltipAttribute("範囲 \nx:横\ny:縦")]
    private Vector2 size;
    [SerializeField]
    private Transform startObject;
    private int ballDelete;
	// Use this for initialization
	void Start () {

        size.x = size.x * 0.9999999f / 2.0f;
        size.y = size.y * 0.9999999f / 2.0f;

        Vector3 ps = startObject.position;

        // 縦横のサイズ以内に指定数生成
        for (int i = 0; i < num; ++i)
        {
            float x = Random.Range(size.x * -1.0f, size.x);
            float y = Random.Range(size.y * -1.0f, size.y);
            GameObject.Instantiate(ball, new Vector3(ps.x + x , ps.y + y , this.transform.position.z), Quaternion.identity , startObject);
        }

        ballDelete = 0;
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public int GetBallNumStart()
    {
        return num;
    }

    public void AddBallDelete()
    {
        ++ballDelete;
    }

    public int GetBallDelete()
    {
        return ballDelete;
    }

	public void RestartInstace()
	{
		ballDelete = 0;

		// ボール消し
		Transform[] tr = startObject.GetComponentsInChildren<Transform>();
		for(int i = 1;i<tr.Length;++i)
		{
			Destroy(tr[i].gameObject);
		}


		Vector3 ps = startObject.position;
		// 縦横のサイズ以内に指定数生成
		for (int i = 0; i < num; ++i)
		{
			float x = Random.Range(size.x * -1.0f, size.x);
			float y = Random.Range(size.y * -1.0f, size.y);
			GameObject.Instantiate(ball, new Vector3(ps.x + x, ps.y + y, this.transform.position.z), Quaternion.identity, startObject);
		}

	}

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class haveSprite : MonoBehaviour {
    [SerializeField]
    private Sprite sprite;

    public Sprite HaveSprite
    {
        get { return sprite; }
        set { sprite = value; }
    }
}

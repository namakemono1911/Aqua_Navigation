﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class remainingNumberController : MonoBehaviour
{

	[SerializeField]
	private Sprite[] numberImages;

	[SerializeField]
	private Image[] digit = new Image[2];

	[SerializeField]
	private int remaining;

	private int oldRemaining = 0;
	private int remainingIndex;
	private Vector2 textureSize;


	public int RemainingIndex
	{
		get { return remainingIndex; }
		set { remainingIndex = value; }
	}

	public int Remaining
	{
		get { return remaining; }
		set { remaining = value; }
	}

	// Use this for initialization
	void Start()
	{
		textureSize = new Vector2(5.0f / 2, 2.0f / 2);
		remainingIndex = remaining;
	}

	// Update is called once per frame
	void Update()
	{
		//上限下限
		if (remainingIndex < 0)
			remainingIndex = 0;
		//     if (remainingIndex > 99)
		//remainingIndex = 99;

		//if (remainingIndex == oldRemaining)
		//	return;

		if (remainingIndex == 0)
		{
			for (int i = 0; i < digit.Length; i++)
			{
				digit[i].sprite = numberImages[0];
			}
			return;
		}

		int index = remainingIndex;
		for (int i = 0; i < digit.Length; i++)
		{
			digit[i].sprite = numberImages[index % 10];
			index /= 10;
		}

		oldRemaining = remainingIndex;
	}

	public void resetRemaining()
	{
		remainingIndex = remaining;
	}

	public void subRemaining()
	{
		remainingIndex--;

		if (remainingIndex < 0)
		{
			remainingIndex = 0;
		}

	}

	public void addRemaining()
	{
		remainingIndex++;

		if (remainingIndex > remaining)
		{
			remainingIndex = remaining;
		}
	}
}

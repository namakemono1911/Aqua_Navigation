﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class missionStarController : MonoBehaviour {

	[SerializeField]
	private Image star1;
	[SerializeField]
	private Image star2;

	[SerializeField]
	private Color trueColor;
	[SerializeField]
	private Color falseColor;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void SetColor(bool st1 , bool st2)
	{
		if(st1)
		{
			star1.color = new Color(trueColor.r, trueColor.g, trueColor.b, trueColor.a);
		}
		else
		{
			star1.color = new Color(falseColor.r, falseColor.g, falseColor.b, falseColor.a);
		}

		if (st2)
		{
			star2.color = new Color(trueColor.r, trueColor.g, trueColor.b, trueColor.a);
		}
		else
		{
			star2.color = new Color(falseColor.r, falseColor.g, falseColor.b, falseColor.a);
		}
	}
}

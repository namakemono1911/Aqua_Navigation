﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotateStage : MonoBehaviour {

    [SerializeField]
    private GameObject stageObj;    // 回転

    [SerializeField]
    private float rotateAmount;     // 回転量

    [SerializeField]
    private Vector2 rotateRimit;    // ステージ回転量の制限(x : 左 , y : 右)

	// Use this for initialization
	void Start () {
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.A))
        {
            stageObj.transform.Rotate(new Vector3(0, 0, rotateAmount));
        }
        if (Input.GetKey(KeyCode.D))
        {
            stageObj.transform.Rotate(new Vector3(0, 0, -rotateAmount));
        }
    }
}

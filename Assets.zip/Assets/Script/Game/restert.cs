﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class restert : MonoBehaviour {
    public void restertButton()
    {
        FadeManager.FadeOut(SceneManager.GetActiveScene().buildIndex);
    }
}

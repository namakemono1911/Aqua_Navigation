﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class roupController : MonoBehaviour {

	// ロープ設定に必要なパラメーター
	[SerializeField]
	private GameObject rightRoup;
	[SerializeField]
	private GameObject Roup;

	[SerializeField,Tooltip("ボール最大数")]
	private int ballMax;
	[SerializeField,Tooltip("チェックを入れると右、入れないと左が受け皿になる")]
	private bool bRight;
	[SerializeField]
	private float roupWidth;

	private int leftBall;

	// Use this for initialization
	void Start () {
		leftBall = 0;

		// leftとrightを探す
		Transform[] tr = this.transform.GetComponentsInChildren<Transform>();
		foreach (Transform child in tr)
		{
			if (child.tag == "kasssya_left")
			{
				Roup = child.gameObject;
			}
			else if(child.tag == "kasssya_right")
			{
				rightRoup = child.gameObject;
			}
		}

		// 反転フラグ
		if(bRight)
		{
			GameObject gm = rightRoup;
			rightRoup = Roup;
			Roup = gm;
		}

	}

	// Update is called once per frame
	void Update () {

		// 右と左で割合決定
		//Debug.Log("左の玉の数 : " + leftBall.ToString());

		leftBall = rightRoup.transform.GetComponent<roupScript>().GetNumBall();
		leftBall = Roup.transform.GetComponent<roupScript>().GetNumBall();
		float per = (float)leftBall / (float)ballMax;
		Roup.GetComponent<roupScript>().SetLength(roupWidth , 1.0f - per);
		rightRoup.GetComponent<roupScript>().SetLength(roupWidth , per);
	}
}

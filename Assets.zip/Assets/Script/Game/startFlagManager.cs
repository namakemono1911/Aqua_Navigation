﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class startFlagManager : MonoBehaviour {

    private bool start;


	// Use this for initialization
	void Start () {
        start = false;
    }

    public void OnStart()
    {
        start = true;
    }
    public void OffStart()
    {
        start = false;
    }
    public bool GetStartFlag()
    {
        return start;
    }
}

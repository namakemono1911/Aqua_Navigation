﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageMiniObjectInstanser : MonoBehaviour
{

    [SerializeField]
    private GameObject instanceObject;
	[SerializeField]
    private Vector2 instanceSpace;
    [SerializeField]
    private Vector2Int instanceCount;
    [SerializeField]
    private int life;
    private bool bBreak;
    // Use this for initialization
    void Start()
    {
        bBreak = false;

    }

    // Update is called once per frame
    void Update()
    {

        if (life > 0 || bBreak == true)
            return;

        bBreak = true;
        SetObject();
        Destroy(this.gameObject);

    }

    private void SetObject()
    {
        //   一つ分の移動
        float x = instanceSpace.x / (float)instanceCount.x;
        float y = instanceSpace.y / (float)instanceCount.y;

        Vector3 pos = this.transform.position;

        int i = 0;

        Debug.Log(pos);

		for (float u = instanceSpace.x / -2.0f; u <= instanceSpace.x / 2.0f; u += x)
        {
            for (float v = instanceSpace.y / -2.0f; v <= instanceSpace.y / 2.0f; v += y)
            {
                ++i;
                GameObject.Instantiate(instanceObject, new Vector3(pos.x + u, pos.y + v, pos.z), Quaternion.identity, this.transform.parent);
                Debug.Log("個数" + i.ToString() + " : 座標 : " + pos);
            }
        }
    }

	public void SubLife()
	{
		--life;
	}
}

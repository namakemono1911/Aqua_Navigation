﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baketu : MonoBehaviour {

    [SerializeField]
    private BoxCollider2D box1;
    [SerializeField]
    private BoxCollider2D box2;
    [SerializeField]
    private BoxCollider2D box3;

    public void OffBoxCollider() {
        box1.enabled = false;
        box2.enabled = false;
        box3.enabled = false;
    }
}

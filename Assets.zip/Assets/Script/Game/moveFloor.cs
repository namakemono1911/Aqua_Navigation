﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveFloor : MonoBehaviour {
    [SerializeField]
    private Transform point1;       //移動ポイント1

    [SerializeField]
    private Transform point2;       //移動ポイント2

    [SerializeField]
    private float moveSpeed;        //進行スピード

    private Vector2 moveVec;        //進行方向
    private bool headedPoint1;      //ポイント1に向かってるかどうか

	// Use this for initialization
	void Start ()
    {
        headedPoint1 = false;
        this.transform.position = point1.position;
        moveVec = point2.position - point1.position;
        moveVec = moveVec.normalized;
	}
	
	// Update is called once per frame
	void Update ()
    {
        // 床移動
        this.transform.position += new Vector3(moveVec.x, moveVec.y, 0.0f) * moveSpeed;

        // ポイントの一定範囲内に入っているかどうか
        if (headedPoint1 == true && (point1.position - this.transform.position).sqrMagnitude < 0.5f)
        {
            headedPoint1 = false;
            moveVec *= -1;
            Debug.Log("hit point1");
        }

        if (headedPoint1 == false && (point2.position - this.transform.position).sqrMagnitude < 0.5f)
        {
            headedPoint1 = true;
            moveVec *= -1;
            Debug.Log("hit point2");
        }
    }
}

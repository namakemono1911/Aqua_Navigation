﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageRoad01 : MonoBehaviour {

    [SerializeField]
    private Transform moveVecObj;  // 勢いの位置
    [SerializeField]
    private float power;        // 与える力
    private Vector3 moveVec;     // 勢いの向き

	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
        if (this.transform.parent.GetComponent<startFlagManager>().GetStartFlag())
        {
			Rigidbody2D rigit = this.transform.parent.GetComponent<Rigidbody2D>();
			rigit.simulated = true;
			moveVec = moveVecObj.position - this.transform.position;
        }
		else
		{
			// 親のrigitBody2Dを消す
			Rigidbody2D rigit = this.transform.parent.GetComponent<Rigidbody2D>();
			rigit.simulated = false;
		}
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "transer" &&
            this.transform.parent.GetComponent<startFlagManager>().GetStartFlag())
        {
            Debug.Log("hit");
            Rigidbody2D a = collision.gameObject.GetComponent<Rigidbody2D>();
            a.AddForce(new Vector2(moveVec.normalized.x, moveVec.normalized.y) * power);
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bgUVScroll : MonoBehaviour {

	[SerializeField]
	private float time;
	[SerializeField]
	private SpriteRenderer rend;
	[SerializeField]
	private Transform pos;

	private float speed;
	private Vector2 uv;
	// Use this for initialization
	void Start () {
		speed = time;
	}

	// Update is called once per frame
	void Update () {

		Vector3 p = this.transform.position;
		p.x -= speed;

		if(p.x <= Screen.width * -1.0f)
		{
			p = pos.position;
		}

		this.transform.position = new Vector3(p.x, p.y, p.z);

	}
}

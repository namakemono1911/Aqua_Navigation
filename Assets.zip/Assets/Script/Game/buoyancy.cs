﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buoyancy : MonoBehaviour {
    [SerializeField, TooltipAttribute("浮力")]
    private float buoyancyPower;
    [SerializeField]
    private buoyancyCount ballCountScript;
    private int numBall = 0;

    private void FixedUpdate()
    {
        float parsent = numBall / ballCountScript.NumBall;
        this.GetComponent<Rigidbody2D>().AddForce(Vector2.up * buoyancyPower);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "transer")
            return;

        numBall++;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseContller : MonoBehaviour {

    [SerializeField]
    private GameObject obj;
    private Vector3 mousePos;   // マウス座標

	private bool isHave;

    // Use this for initialization
    void Start() {
		isHave = false;
	}

    // Update is called once per frame
    void Update() {
        // マウスの位置に移動させる
        mousePos = Input.mousePosition;
        mousePos = Camera.main.ScreenToWorldPoint(mousePos);
        //Debug.Log("マウス座標 x:"+mousePos.x + " , y:" + mousePos.y + " , z: 0 ");
        obj.transform.position = new Vector3(mousePos.x, mousePos.y, obj.transform.position.z);


		// オブジェクトを持っているか
		int cntChild = this.transform.parent.childCount;
		Transform parent = this.transform.parent;
		isHave = false;
		for(int i = 1; i < cntChild;++i)
		{
			// スタンプがonなら持っている
			if(parent.GetChild(i).GetComponent<stageGridEditor>().isStampState())
			{
				Debug.Log("isHave = true");
				isHave = true;
			}
		}


	}

    // マウスの座標取得
    public Vector3 GetMousePos() {
        return mousePos;
    }

    public bool GetIsMouseObjectHavingAnything(){
        Transform tr = this.transform.parent.GetComponent<Transform>();
        foreach (Transform child in tr)
        {
            if (child.tag != "stageEditor")
                continue;

            if (child.GetComponent<stageGridEditor>().GetMouseFlag())
                return true;
        }

        return false;
    }

    public bool MouseHitUI()
    {
        if (this.transform.position.x <= -384 || this.transform.position.x >= 384)
            return false;

        return true;
    }

	public bool DoYouHaveAnyObject()
	{
		return isHave;
	}

	// マウスが画面外華道か
	public bool isDiplayOut()
	{
		Vector3 pos = this.transform.position;
		if(pos.x <= -384)
		{
			return true;
		}

        //		if(pos.x >= 384 && pos.y <= -109)
        if(pos.x >= 384)
        {
            return true;
		}

		return false;
	}
}

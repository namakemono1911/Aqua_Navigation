﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class numWaterController : MonoBehaviour
{
	[SerializeField]
	private ruleManager ruleManager;   //ルールマネージャー
	private remainingNumberController remainingController;

	private void Start()
	{
		remainingController = GetComponent<remainingNumberController>();
		remainingController.Remaining = ruleManager.getNumStartBall();
	}

	private void Update()
	{
		remainingController.RemainingIndex = ruleManager.getNumBall();

		Debug.Log(ruleManager.getNumBall().ToString());

	}
}

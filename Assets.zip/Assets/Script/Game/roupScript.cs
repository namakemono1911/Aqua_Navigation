﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class roupScript : MonoBehaviour {

	private Vector2 TexSize;
	private SpriteRenderer rend;
	private Vector2 SpriteSize;
	private int nball;

	// Use this for initialization
	void Start () {
		rend = this.GetComponent<SpriteRenderer>();

		// 元のサイズ取得
		TexSize = rend.size;
		SpriteSize = new Vector2(TexSize.x * this.transform.localScale.x , TexSize.y * this.transform.localScale.y);

		nball = 0;
	}
	
	// Update is called once per frame
	void Update () {
		//rend.material.SetTextureOffset("_MainTex", new Vector2(v, 0));
	}

	public int GetNumBall()
	{
		return nball;
	}

	public void AddNumBall(bool exit = false)
	{
		if(exit)
		{
			--nball;
			if (nball < 0)
			{
				nball = 0;
			}
			return;
		}
		++nball;
	}

	public void SetLength(float x , float y)
	{
		// 変更したいサイズと、今のサイズの比較
		Vector2 scale;
		scale.x = x / TexSize.x;
		scale.y = y / TexSize.y;
		rend.size = new Vector2(scale.x, scale.y);

		// UVも比率に従って変更→scaleと同値
		Vector2 uv;
		uv = scale;
		rend.material.SetTextureOffset("_MainTex", new Vector2(uv.x, -uv.y));

	}
}

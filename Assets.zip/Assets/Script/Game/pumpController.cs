﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pumpController : MonoBehaviour {
    [SerializeField]
    private Transform launcherPos;
    [SerializeField]
    private Transform fileAngle;
    [SerializeField]
    private float power;

    private Vector2 angleVec;

	// Use this for initialization
	void Start ()
    {
        Vector2 angle = new Vector2(fileAngle.parent.transform.eulerAngles.z + fileAngle.eulerAngles.z,
            fileAngle.parent.transform.eulerAngles.y + fileAngle.eulerAngles.y);
        angleVec = new Vector2(Mathf.Cos((fileAngle.eulerAngles.z) * Mathf.PI / 180), Mathf.Sin(fileAngle.eulerAngles.z * Mathf.PI / 180));
        angleVec.x *= Mathf.Cos(fileAngle.eulerAngles.y * Mathf.PI / 180);
        angleVec *= 1000;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "transer" ||
            this.transform.parent.GetComponent<startFlagManager>().GetStartFlag() == false)
            return;

        //発射口に玉を移動
        collision.transform.position = launcherPos.position;

        //発射
        Vector2 angle = new Vector2(fileAngle.parent.transform.eulerAngles.z + fileAngle.eulerAngles.z,
            fileAngle.parent.transform.eulerAngles.y + fileAngle.eulerAngles.y);
        angleVec = new Vector2(Mathf.Cos((fileAngle.eulerAngles.z) * Mathf.PI / 180), Mathf.Sin(fileAngle.eulerAngles.z * Mathf.PI / 180));
        angleVec.x *= Mathf.Cos(fileAngle.eulerAngles.y * Mathf.PI / 180);

        angleVec *= 1000;
        Vector2 force = angleVec * power;
        collision.gameObject.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        collision.gameObject.GetComponent<Rigidbody2D>().AddForce(force);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class numGoalWaterController : MonoBehaviour
{
	[SerializeField]
	private ruleManager ruleManager;   //ルールマネージャー
	private remainingNumberController remainingController;

	private void Start()
	{
		remainingController = GetComponent<remainingNumberController>();
		remainingController.Remaining = 0;
	}

	private void Update()
	{
		remainingController.RemainingIndex = ruleManager.getNumGoalBall();
	}
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dyson : MonoBehaviour {
    [SerializeField]
    private float dysonPower;
    private BoxCollider2D box;
    private float val = 0;
	// Use this for initialization
	void Start () {
        box = GetComponent<BoxCollider2D>();
	}
	
	// Update is called once per frame
	void Update () {
        var vec = box.offset;
        vec.y += Mathf.Sin(val);
        box.offset = vec;
        val += 0.1f;
	}

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "transer" ||
            this.transform.parent.GetComponent<startFlagManager>().GetStartFlag() == false)
            return;

        Vector3 vecToEntrance = (transform.position - collision.transform.position).normalized * dysonPower;
        collision.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(vecToEntrance.x, vecToEntrance.y));
    }
}

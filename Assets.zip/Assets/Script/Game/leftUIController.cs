﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class leftUIController : MonoBehaviour
{

	[SerializeField]
	ruleManager rule;

	CanvasGroup play;
	CanvasGroup stop;
	CanvasGroup escape;
	private bool bEscape;
	// Use this for initialization
	void Start()
	{

		bEscape = false;

		int cntChild = this.transform.childCount;

		for (int i = 0; i < cntChild; ++i)
		{
			Transform tr = this.transform.GetChild(i);
			if (tr.tag == "playCanvas")
			{
				play = tr.GetComponent<CanvasGroup>();

				int iiiii = 0;
			}
			else if (tr.tag == "stopCanvas")
			{
				stop = tr.GetComponent<CanvasGroup>();
				int iiiii = 0;
			}
			else if (tr.tag == "escapeCanvas")
			{
				escape = tr.GetComponent<CanvasGroup>();
				int iiiii = 0;
			}
		}
	}

	// Update is called once per frame
	void Update()
	{

		bool a = rule.GetGameRunnning();

		// スタートフラグ次第
		if (rule.GetGameRunnning() == true)
		{
			play.alpha = 1;
			play.blocksRaycasts = true;

			stop.alpha = 0;
			stop.blocksRaycasts = false;
		}
		else
		{
			stop.alpha = 1;
			stop.blocksRaycasts = true;

			play.alpha = 0;
			play.blocksRaycasts = false;
		}



		// スケープ次第
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			bEscape = !bEscape;
		}


		if (bEscape)
		{
			escape.alpha = 1;
			escape.blocksRaycasts = true;
		}
		else
		{
			escape.alpha = 0;
			escape.blocksRaycasts = false;
		}

	}

	public bool GetEscape()
	{
		return bEscape;
	}
}

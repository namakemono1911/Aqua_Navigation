﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stageGridEditor : MonoBehaviour {
    [SerializeField]
    private GameObject stageObject;         // マウス
    [SerializeField]
    private mouseContller mousePos;         // マウススクリプト
    [SerializeField]
    private float lengthShort;              // 移動する範囲
    [SerializeField]
    private Vector2 collisionNum;           // コリジョンの個数
    [SerializeField]
    private GameObject collisons;           // コリジョンの親
    [SerializeField]
    private bool moveStart;                 // 生成された時からついているか
    private BoxCollider2D[] stages; // コリジョン
    private bool move;              // 移動するかしないか
    private float distanceNow;      // 現在最小の距離
    private bool Vec;   // true 右 : false 左
	[SerializeField]
	private bool isStamp;   // スタンプ元
	private bool canInstance;

	[SerializeField]
	private remainingNumberController buttonObject;
	// Use this for initialization
	void Start () {
        // 名前でゲームオブジェクト検索
        Transform collisionsU;
        Transform collisionsV;

		stages = new BoxCollider2D[(int)collisionNum.x * (int)collisionNum.y];

        for (int u = 0; u < collisionNum.x; ++u)
        {
            collisionsU = collisons.transform.Find(u.ToString());
            if (!collisionsU)
            {
                break;
            }

            for (int v = 0; v < collisionNum.y; ++v)
            {
                collisionsV = collisionsU.Find(v.ToString());
                if (!collisionsV)
                {
                    break;
                }

                stages[(int)collisionNum.y * u + v] = collisionsV.GetComponent<BoxCollider2D>();
            }
        }

        // 追従フラグ
        if(moveStart)
            move = true;

		canInstance = false;

	}
	
	// Update is called once per frame
	void Update () {

		if (mousePos == null)
		{
			Debug.Log("マウスが無い : " + this.name);
			return;
		}

		// スタンプなら
		// 今まで通り当たり判定して、おけるところにinstanceate
		if (isStamp == true)
		{
			canInstance = false;
			// 反転作業
			if (Input.GetMouseButtonDown(1))
			{
				Debug.Log("右クリック");
				Vec = !Vec;
				this.transform.Rotate(new Vector3(0, 180, 0));
			}

			// 当たり判定、物体生成
			if (this.GetComponent<limitLength>().isPath())
			{
				for (int i = 0; i < stages.Length; ++i)
				{
					float distance = Vector3.Distance(stages[i].transform.position, mousePos.GetMousePos());

					if (distance <= distanceNow && lengthShort >= distance)
					{
						distanceNow = distance;
						stageObject.transform.position = new Vector3(stages[i].transform.position.x, stages[i].transform.position.y, this.transform.position.z);


						canInstance = true;

					}
				}
			}

			if(canInstance == true)
			{
				if (Input.GetMouseButtonDown(0) && buttonObject.RemainingIndex > 0)
				{
					GameObject gm;
					Vector3 pos = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.parent.position.z);
					gm = GameObject.Instantiate(this.gameObject, pos, this.transform.rotation, this.transform.parent);
					// 名前変更
					gm.name = this.name;
					// マウス追従解除
					gm.GetComponent<stageGridEditor>().nonMove();
					// マウス入れる
					gm.GetComponent<stageGridEditor>().SetMouseScript(this.mousePos);
					// スタンプをnull
					gm.GetComponent<stageGridEditor>().nonStanp();
					///////////////////////////
					// ui -1
					buttonObject.subRemaining();
					///////////////////////////

					if(buttonObject.RemainingIndex <= 0)
					{
						Destroy(this.gameObject);
					}
				}
			}

			// マウス追従
			if (distanceNow >= lengthShort)
			{
				stageObject.transform.position = new Vector3(mousePos.GetMousePos().x, mousePos.GetMousePos().y, -5);
			}

			distanceNow = 1000000;

			// 画面外でクリックでデリート
			if(mousePos.isDiplayOut() && Input.GetMouseButtonDown(0))
			{
				Destroy(this.gameObject);
			}


		}
		else
		{
			Debug.Log("生成 : " + this.name.ToString());

			// スタンプでないなら
			// 当たり判定いらない
			// ただ、動かしたいときは、スタンプと当たり判定して、clickされたら自分を消す
			if (mousePos.transform.position.x > this.transform.position.x - (this.GetComponent<BoxCollider2D>().size.x * this.transform.localScale.x) / 2.0f &&
				mousePos.transform.position.x < this.transform.position.x + (this.GetComponent<BoxCollider2D>().size.x * this.transform.localScale.x) / 2.0f &&
				mousePos.transform.position.y < this.transform.position.y + (this.GetComponent<BoxCollider2D>().size.y * this.transform.localScale.y) / 2.0f &&
				mousePos.transform.position.y > this.transform.position.y - (this.GetComponent<BoxCollider2D>().size.y * this.transform.localScale.y) / 2.0f
				)
			{
				if (Input.GetMouseButtonDown(0)  && this.GetComponent<startFlagManager>().GetStartFlag() == false && !mousePos.DoYouHaveAnyObject())
				{
					// マウスに何もついていなければ
					// くっつく
					buttonObject.addRemaining();

					isStamp = true;
					// 何かついていれば
					// 何もしない
				}

				if(Input.GetMouseButtonDown(1) && this.GetComponent<startFlagManager>().GetStartFlag() == false && !mousePos.DoYouHaveAnyObject())
				{
					////////////////////////////////////
					// uiに+1
					buttonObject.addRemaining();
					////////////////////////////////////
					// 自分を消す
					Destroy(this.gameObject);
				}
			}
		}

	}

	public void SetMouseScript(mouseContller mouse)
    {
        mousePos = mouse;
    }

    public bool GetMouseFlag()
    {
        return move;
    }
	public void nonMove()
	{
		move = false;
		moveStart = false;
	}

	// 生成するとき呼ぶ
	public void nonStanp()
	{
		isStamp = false;
	}

	// onstart使うときとかに確認する
	public bool isStampState()
	{
		return isStamp;
	}

	public void nonMouseScript()
	{
		mousePos = null;
	}

	public void setButton(remainingNumberController cont)
	{
		buttonObject = cont;
	}


	public remainingNumberController getButton()
	{
		return buttonObject;
	}

}

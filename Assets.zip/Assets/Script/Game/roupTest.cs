﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class roupTest : MonoBehaviour {

    [SerializeField,Tooltip("始点")]
    private GameObject startObject; // 始点
    [SerializeField, Tooltip("終点")]
    private GameObject endObject;   // 終点
    [SerializeField, Tooltip("中間オブジェクト")]
    private GameObject duringObject;  // 中間の者達
    [SerializeField, Tooltip("x:紐の長さ\ny:紐の太さ")]
    private Vector2 size;           // 長さ、太さ
    [SerializeField, Tooltip("区分け数")]
    private int Division;           // 区分け数

    private GameObject[] roupObjects;

	// Use this for initialization
	void Start () {
        roupObjects = new GameObject[Division + 2];

        // 長さ、位置計算
        // 1つの長さ計算
        // 紐の長さ / 区分け数 = 1ブロックの長さ
        float lengthOne = size.x / (float)Division;
        // 中間オブジェクトの大きさ = spriteRenderer.Sprite.size * transform.scal
        Vector2 duringSize;
        float x = duringObject.GetComponent<SpriteRenderer>().size.x;
        float y = duringObject.GetComponent<SpriteRenderer>().size.y;
        duringSize = new Vector2(x, y);
        // 中間オブジェクトの大きさを1ブロックの長さにする
        // sizeとduringSizeを比較してscaleを決める
        Vector3 ScaleSize = new Vector3(1,1,1);
        ScaleSize.x = lengthOne / x;
        ScaleSize.y = size.y / y;
        duringObject.transform.localScale = new Vector3(ScaleSize.x , ScaleSize.y , ScaleSize.z);

        // 始点生成
        Vector3 pos;
        pos = new Vector3(this.transform.position.x + size.x / -2.0f, this.transform.position.y, this.transform.position.z);
        roupObjects[0] = GameObject.Instantiate(startObject, new Vector3(pos.x, pos.y, pos.z), startObject.transform.rotation, this.transform);
        // 中間生成
        for (int i = 1; i < Division - 1; ++i)
        {
            pos = new Vector3(this.transform.position.x + size.x/-2.0f + (lengthOne*i), this.transform.position.y, this.transform.position.z);
            roupObjects[i] = GameObject.Instantiate(duringObject,new Vector3(pos.x, pos.y, pos.z),Quaternion.identity,this.transform);
        }
        // 終点生成
        pos = new Vector3(this.transform.position.x + size.x / 2.0f - lengthOne / 2.0f, this.transform.position.y, this.transform.position.z);
        roupObjects[Division - 1] =
            GameObject.Instantiate(endObject, new Vector3(pos.x, pos.y, pos.z), endObject.transform.rotation, this.transform);

        // HingeJointに当てはめる
        for (int i = 0; i < Division - 1; ++i)
        {
            roupObjects[i].GetComponent<HingeJoint2D>().connectedBody = roupObjects[i + 1].GetComponent<Rigidbody2D>();
        }

    }

    // Update is called once per frame
    void Update () {
    }
}

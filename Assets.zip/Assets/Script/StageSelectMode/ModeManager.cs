﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModeManager : MonoBehaviour {

    // モード識別子
    public static class StageSelectMode_Key
    {
        // シーン番号
        public const int MODE_ITEMSELECT   = 0;  // アイテムセレクトモード 
        public const int MODE_STAGESELECT  = 1;  // ステージセレクトモード
    }

    // 初期モード
    private int Mode = StageSelectMode_Key.MODE_ITEMSELECT;

    // 他のオブジェクト
    public GameObject ItemIcon;     // アイテム表示オブジェクト
    public GameObject StageIcon;    // ステージ表示オブジェクト
    public GameObject Alpha_Group;  // アルファグループ

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    // モード移行
    public void Change_Mode(int NextMode)
    {
        Mode = NextMode;
    }

    // バック処理
    public void Back()
    {
        // タイトルへ
        if (Mode == StageSelectMode_Key.MODE_ITEMSELECT)
        {
            // モード移行とフェード呼び出し
            FadeManager.FadeOut(0, 1.0f);
        }
        // ステージセレクト表示へ移行
        else if (Mode == StageSelectMode_Key.MODE_STAGESELECT)
        {
            // ステージアイコン表示をオフに
            StageIcon.GetComponent<StageChildIconGroup>().Group_DrawOff();
            // ディスプレイ群を非表示に
            Alpha_Group.GetComponent<alpha_Group>().Group_DrawOff();
            // ステージ大枠表示をオンに
            ItemIcon.GetComponent<ItemIconGroup>().Group_DrawOn();

            // モード切替
            Mode = StageSelectMode_Key.MODE_ITEMSELECT;
        }
        
    }
}

﻿/////////////////////////////////////////////////////////
//
//	ステージセレクト大枠グループ
//
//	Data	: 2018/05/18
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

[RequireComponent(typeof(CanvasGroup))]

public class ItemIconGroup : MonoBehaviour
{
    // メンバ
    private SpriteRenderer  SpRenderer      = null;                         // スプライトレンダラー
    private CanvasGroup     CanvasGroup     = null;                         // キャンバスグループ
    private Image[]         Child_Image     = { null };                     // 自身の子要素(imageのみ)
    private Vector2         NormalSize      = new Vector2(150.0f, 150.0f);  // 通常時のサムネイルサイズ
    private Vector2         EnlargeSize     = new Vector2(160.0f, 160.0f);  // 拡大時のサムネイルサイズ


    // 初期化処理
    void Start()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 下段レイヤーへの判定を切る
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.interactable = true;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();
    }

    // 更新処理
    void Update()
    {
    }

    // 表示をオフへ
    public void Group_DrawOff()
    {
        // デバッグ表示
        Debug.Log("ステージセレクト : 大枠表示から小枠表示へ移行");

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = false;
        }

        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0f;

        gameObject.SetActive(false);
    }

    // 表示をオンへ
    public void Group_DrawOn()
    {
        // デバッグ表示
        Debug.Log("ステージセレクト : 小枠表示から大枠表示へ移行");

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }

        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }

    // カーソルオン
    public void MauseOn(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオン");

        // イメージ画像の拡大
        Child_Image[Index].GetComponent<RectTransform>().sizeDelta = EnlargeSize;
    }

    // カーソルオフ
    public void MauseOff(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオフ");


        // イメージ画像の拡大
        Child_Image[Index].GetComponent<RectTransform>().sizeDelta = NormalSize;
    }
}


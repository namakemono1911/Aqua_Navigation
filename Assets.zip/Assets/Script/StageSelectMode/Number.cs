﻿/////////////////////////////////////////////////////////
//
//	ナンバーグループ
//
//	Data	: 2018/06/26
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Common;

[RequireComponent(typeof(CanvasGroup))]

public class Number : MonoBehaviour
{

    // メンバ
    private SpriteRenderer SpRenderer = null;  // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;  // キャンバスグループ
    private Image Image = null;              // 自身の子要素(imageのみ)

    // テクスチャ取得
    private Dictionary<string, Sprite> Thumbnail_Dic;

    // テクスチャ管理
    private string TextureName = null;

    // Use this for initialization
    void Start()
    {
        // リソースフォルダから全サムネイルデータを取得
        Thumbnail_Dic = new Dictionary<string, Sprite>();
        object[] Thumbnail_List = Resources.LoadAll(Stage_Select_DataKey.STAGE_LENGTH_PATH, typeof(Sprite));

        // ディクショナリー内に保管
        foreach (Sprite Tex in Thumbnail_List)
        {
            Thumbnail_Dic[Tex.name] = Tex;
        }

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 子要素のイメージコンポーネント取得
        Image = this.GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {

        if (TextureName != null)
        {
            if (Image.sprite == null)
            {
                // テクスチャの変更
                Image.sprite = Thumbnail_Dic[TextureName] as Sprite;
            }

        }

    }

    // 画像切り替え
    public void Number_Change(string texture)
    {

        TextureName = texture;

        if (texture != null)
        {
            // テクスチャの変更
            Image.sprite = Thumbnail_Dic[texture] as Sprite;
        }
        else if (texture == null)
        {
            // テクスチャの変更
            Image.sprite = null;
        }
    }
}


﻿/////////////////////////////////////////////////////////
//
//	ステージセレクト,ルール制御
//
//	Data	: 2018/06/26
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using Common;

[RequireComponent(typeof(CanvasGroup))]

public class Rule_Display : MonoBehaviour
{
    // メンバ
    private SpriteRenderer SpRenderer = null;   // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;     // キャンバスグループ
    private Image[] Child_Image = { null };     // 自身の子要素(imageのみ)

    // フラグ
    private bool[] Star_Flag = { false, false};
    private int[] GameRule = { 0, 0};

    // 全テクスチャデータ
    private Dictionary<string, Sprite> Texture_Dic;
    private dataManager.Data StageData;
    private dataManager dataManager;


	// ルール
	[SerializeField]
	private int[] rules;
    //=================================================================================
    //  初回読み込み
    //=================================================================================
    private void Awake()
    {
        // リソースフォルダから全サムネイルデータを取得
        Texture_Dic = new Dictionary<string, Sprite>();
        object[] Thumbnail_List = Resources.LoadAll(Result_DataKey.IMAGE_PATH, typeof(Sprite));

        // ディクショナリー内に保管
        foreach (Sprite Tex in Thumbnail_List)
        {
            Texture_Dic[Tex.name] = Tex;
        }
    }

    // 初期化処理
    void Start()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();
        dataManager = this.GetComponent<dataManager>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    // 表示をオンに
    public void Rule_Set(int StageNum)
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

		// セーブデータ呼び出し
		StageData = dataManager.LoadData(StageData, StageNum + 2);	// ビルド設定

        // ステージ進行状況をセット
        Star_Flag[0] = StageData.mission1;
        Star_Flag[1] = StageData.mission2;

        GameRule[0] = 0;
        GameRule[1] = rules[StageNum];

        // セットテクスチャー
        SetTexture();

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }

        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }

    // テクスチャ設定
    private int SetTexture()
    {
        string Name;

        // スターマークの表示切替
        for (int i = 0; i < 2; i++)
        {
            Child_Image[i].enabled = Star_Flag[i];
        }

        // ゲームルールテクスチャをセット
        for (int i = 0; i < 2; i++)
        {
            Name = "Rule" + GameRule[i];
            Child_Image[2 + i].sprite = Texture_Dic[Name] as Sprite;
        }
        return 0;
    }
}

﻿/////////////////////////////////////////////////////////
//
//	アルファ調整グループ
//
//	Data	: 2018/06/27
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

[RequireComponent(typeof(CanvasGroup))]

public class alpha_Group : MonoBehaviour
{
    // メンバ
    private SpriteRenderer SpRenderer = null;                         // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;                         // キャンバスグループ
    private Image[] Child_Image = { null };                     // 自身の子要素(imageのみ)

    // 初期化処理
    void Start()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 下段レイヤーへの判定を切る
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.interactable = true;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // 初期状態 : 非表示
        Group_DrawOff();
    }

    // 非表示
    public void Group_DrawOff()
    {
        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = false;
        }

        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0f;
    }

    // 表示
    public void Group_DrawOn()
    {
        // デバッグ表示
        Debug.Log("ステージセレクト : 小枠表示から大枠表示へ移行");

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }

        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }
}


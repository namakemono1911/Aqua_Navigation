﻿/////////////////////////////////////////////////////////
//
//	ステージセレクト小枠グループ
//
//	Data	: 2018/05/18
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using Common;

[RequireComponent(typeof(CanvasGroup))]

public class StageChildIconGroup : MonoBehaviour
{
    // メンバ
    private SpriteRenderer SpRenderer   = null;                 // スプライトレンダラー
    private CanvasGroup CanvasGroup     = null;                 // キャンバスグループ
    private Image[] Child_Image         = { null };             // 自身の子要素(imageのみ)

    private Vector2 NormalSize  = new Vector2(150.0f, 150.0f);   // 通常時のサムネイルサイズ
    private Vector2 EnlargeSize = new Vector2(160.0f, 160.0f);  // 拡大時のサムネイルサイズ

    private int Head;

    // ゲームオブジェクト
    public GameObject   Display;
    Display             Display_Script;

    // ステージ番号表示
    public GameObject   number;
    Number              number_Script;

    // ルール表示
    public GameObject   Rule;
    Rule_Display Rule_Script;

    // アイテムリスト
    public GameObject Item_List;
    Item_Display Item_Display_Script;

    // 全サムネイルデータ
    private Dictionary<string, Sprite> Thumbnail_Dic;
	private int ItemIndex = 0;

    //=================================================================================
    //  初回読み込み
    //=================================================================================
    private void Awake()
    {
        // リソースフォルダから全サムネイルデータを取得
        Thumbnail_Dic = new Dictionary<string, Sprite>();
        object[] Thumbnail_List = Resources.LoadAll(Stage_Select_DataKey.STAGE_PATH,typeof(Sprite));

        // ディクショナリー内に保管
        foreach (Sprite Tex in Thumbnail_List)
        {
            Thumbnail_Dic[Tex.name] = Tex;
        }
    }

    // 初期化処理
    void Start()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 下段レイヤーへの判定を切る
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.interactable = true;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // オブジェクト取得
        Display 　= GameObject.Find("Display");
        number　  = GameObject.Find("number");
        Rule      = GameObject.Find("Rule_Display");
        Item_List = GameObject.Find("Item_Display");
    }

    // 更新処理
    void Update()
    { }

    // 表示をオフへ
    public void Group_DrawOff()
    {
        // デバッグ表示
        Debug.Log("ステージセレクト : ステージ表示からモチーフ表示へ移行");

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = false;
        }

        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0f;

        gameObject.SetActive(false);
    }

    // 表示をオンへ（大枠のモチーフ番号を指定）
    public void Group_DrawOn(int ItemNumber)
    {
        // デバッグ表示
        Debug.Log("ステージセレクト : モチーフ表示からステージ表示へ移行");

        // 先頭番号
        Head = (ItemNumber * Child_Image.Length);

        ItemIndex = ItemNumber;

        // 大枠表示のレイキャストをオンへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }

        // モチーフ別にステージのサムネイルを表示する
        for (int i = 0; i < Child_Image.Length; i++)
        {
            // サムネイル呼び出しキー作成
           int Index = Head + i;
            string name = "Stage" + Index;
			Child_Image[i].sprite = Thumbnail_Dic[name] as Sprite;
        }
        
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }

    // カーソルオン
    public void MauseOn(int num)
    {
        // デバッグ表示
        Debug.Log("マウスオン");

        // イメージ画像の拡大
        Child_Image[num].GetComponent<RectTransform>().sizeDelta = EnlargeSize;

        // スクリプト取得
        Display_Script      = Display.GetComponent<Display>();
        number_Script       = number.GetComponent<Number>();
        Rule_Script         = Rule.GetComponent<Rule_Display>();
        Item_Display_Script = Item_List.GetComponent<Item_Display>();

        // ステージ番号の割り出し
        int Index = Head + num; 

        // 各テクスチャネームを取得
        string name;
        string LenName;
        string ItemName;

		// サムネイル表示枠
		name = "Stage" + Index;

        // ステージ番号表示枠(10番以降でテクスチャ名が違う為、修正)
        if (Index + 1 < 10){
            LenName = "stage0" + (Index + 1);
        }
        else{
            LenName = "stage" + (Index + 1);
        }

        // アイテムリスト用サムネイル
		if (Index + 1 < 10)
		{
			ItemName = "ItemList0" + (Index + 1);
		}
		else
		{
			ItemName = "ItemList" + (Index + 1);
		}

		// 各表示枠の変更
		Rule_Script.Rule_Set(Index);
        Display_Script.Display_Change(name);
        number_Script.Number_Change(LenName);
        Item_Display_Script.Item_Display_Change(ItemName);
    }

    // カーソルオフ
    public void MauseOff(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオフ");
        
        // イメージ画像の拡大
        Child_Image[Index].GetComponent<RectTransform>().sizeDelta = NormalSize;

        // スクリプト取得
        Display_Script = Display.GetComponent<Display>();
        Display_Script.Display_Change(null);
    }

    // ステージ移行処理
    public void StageFade(int StageID)
    {
        // スクリプト取得
        Display_Script = Display.GetComponent<Display>();

        int Index = Head + StageID;

        string name;
        
        int index = StageID + (5 * ItemIndex);
        FadeManager.FadeOut(index, 1.0f);
    }
}


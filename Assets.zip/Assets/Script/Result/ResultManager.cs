﻿/////////////////////////////////////////////////////////
//
//	リザルトマネージャー
//
//	Data	: 2018/06/14
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

[RequireComponent(typeof(CanvasGroup))]

public class ResultManager : MonoBehaviour {

    // メンバ
    private SpriteRenderer SpRenderer = null;   // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;     // キャンバスグループ

    // ゲームオブジェクト
    public GameObject ButtonGroup;              // ボタングループ
    public GameObject ImageGroup;               // イメージグループ

    // スクリプト
    ButtonManager   buttonManager;              // ボタングループ
    ImageManager    imageManager;               // イメージグループ

    // Use this for initialization
    void Start () {

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // グループコンポーネントを取得
        ButtonGroup = GameObject.Find("ButtonGroup");
        ImageGroup = GameObject.Find("ImageGroup");

        // リザルトの表示を全てオフに
        CanvasGroup.blocksRaycasts = false;
       // CanvasGroup.interactable = false;
        CanvasGroup.alpha = 0.0f;
        gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update () {
	}

    // 表示をオフへ
    public void Result_DrawOff()
    {
        // デバッグ表示
        Debug.Log("リザルト表示をオフにします");

        // スクリプト取得
        buttonManager = ButtonGroup.GetComponent<ButtonManager>();
        imageManager = ImageGroup.GetComponent<ImageManager>();

        // リザルトボタン群の表示をオンに
        buttonManager.DrawOff();
        // イメージグループの表示をオンに
        imageManager.Image_DrawOff();

        // リザルトの表示を全てオフに
        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0.0f;
        gameObject.SetActive(false);
    }

    // 表示をオンへ
    public void Result_DrawOn()
    {
        // デバッグ表示
        Debug.Log("リザルト表示をオンにします");

        gameObject.SetActive(true);

        // リザルト表示を全てオンに
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.interactable = true;
        CanvasGroup.alpha = 1f;

        // スクリプト取得
        buttonManager = ButtonGroup.GetComponent<ButtonManager>();
        imageManager = ImageGroup.GetComponent<ImageManager>();

        // リザルトボタン群の表示をオンに
        buttonManager.DrawOn();
        // イメージグループの表示をオンに
        imageManager.Image_DrawOn();

 
    }
}

﻿/////////////////////////////////////////////////////////
//
//	ボタン群グループ
//
//	Data	: 2018/06/14
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(CanvasGroup))]

public class ButtonManager : MonoBehaviour {

	// セーブ
	[SerializeField]
	private ruleManager rule;

    // メンバ
    private SpriteRenderer SpRenderer = null;                       // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;                         // キャンバスグループ
    private Image[] Child_Image = { null };                         // 自身の子要素(imageのみ)
    private Vector2 NormalSize = new Vector2(150.0f, 100.0f);       // 通常時のボタンサイズ
    private Vector2 restartSize = new Vector2(100.0f, 100.0f);       // 通常時のボタンサイズ

    // 初期化処理
    void Start () {

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();
        
        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    // 表示をオンに
    public void DrawOn()
    {
        // オブジェクトをアクティブに
        gameObject.SetActive(true);

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // レイキャスト貫通防止、不透明状態へ
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1.0f;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // 子要素のレイキャスティングを受け付け開始
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }  
    }

    // 表示をオフ
    public void DrawOff()
    {
        // オブジェクトをアクティブに
        gameObject.SetActive(true);

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // レイキャスト貫通、透明状態へ
        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0.0f;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // 子要素のレイキャスティングを防止
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = false;
        }

        // オブジェクトを非アクティブに
        gameObject.SetActive(false);
    }

    // カーソルオン
    public void MauseOn(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオン");

        if (Index < 2)
        {
            // イメージ画像の拡大
            Child_Image[Index].GetComponent<RectTransform>().sizeDelta = NormalSize * 1.2f;
        }
        else
        {
            // イメージ画像の拡大
            Child_Image[Index].GetComponent<RectTransform>().sizeDelta = restartSize * 1.2f;
        }
    }

    // カーソルオフ
    public void MauseOff(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオフ");

        if (Index < 2)
        {
            // イメージ画像の拡大
            Child_Image[Index].GetComponent<RectTransform>().sizeDelta = NormalSize;
        }
        else
        {
            // イメージ画像の拡大
            Child_Image[Index].GetComponent<RectTransform>().sizeDelta = restartSize;
        }
    }

    // バックボタン
    public void Return_Button()
    {
        FadeManager.FadeOut(1);
    }

    // ネクストボタン
    public void Next_Button()
    {
        int Index = SceneManager.GetActiveScene().buildIndex;

        Index++;
        
        if(Index >= 18) {
            Index = 0;
        }

        FadeManager.FadeOut(Index, 1.0f);
    }

    // リスタートボタン
    public void Restart_Button()
    {
		// リスタート処理
		rule.saveNow();

		int Index = SceneManager.GetActiveScene().buildIndex;
        FadeManager.FadeOut(Index, 1.0f);
    }
}

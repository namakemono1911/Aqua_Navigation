﻿/////////////////////////////////////////////////////////
//
//	ステージセレクト小枠グループ
//
//	Data	: 2018/05/18
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using Common;

[RequireComponent(typeof(CanvasGroup))]

public class ImageManager : MonoBehaviour {

    // メンバ
    private SpriteRenderer SpRenderer = null;   // スプライトレンダラー
    private CanvasGroup CanvasGroup = null;     // キャンバスグループ
    private Image[] Child_Image = { null };     // 自身の子要素(imageのみ)

    // フラグ
    private bool    Result_Flag = false;
    private bool[]  Star_Flag   = { false, false, false };
    private int[]   GameRule    = { 0, 0, 0 };

    // 全テクスチャデータ
    private Dictionary<string, Sprite> Texture_Dic;

    //=================================================================================
    //  初回読み込み
    //=================================================================================
    private void Awake()
    {
        // リソースフォルダから全サムネイルデータを取得
        Texture_Dic = new Dictionary<string, Sprite>();
        object[] Thumbnail_List = Resources.LoadAll(Result_DataKey.IMAGE_PATH, typeof(Sprite));

        // ディクショナリー内に保管
        foreach (Sprite Tex in Thumbnail_List)
        {
            Texture_Dic[Tex.name] = Tex;
        }
    }

    // 初期化処理
    void Start () {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();
        
        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();
    }

    // Update is called once per frame
    void Update () {
		
	}

    // 表示をオンに
    public void Image_DrawOn()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // リザルトデータ取得
        GetResultData();
        // セットテクスチャー
        SetTexture();

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }

        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }

    // 表示をオフ
    public void Image_DrawOff()
    {
        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();


        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = false;
        }

        CanvasGroup.blocksRaycasts = false;
        CanvasGroup.alpha = 0f;

        gameObject.SetActive(false);
    }

    // 表示データ取得
    private int GetResultData()
    {
		// クリアorゲームオーバ状態取得
		// →ルールマネージャーからもらう

		// ミッション達成状況取得
		// →ルールマネージャーからもらう

		// ステージ事のルール設定

		return 0;
    }

    // テクスチャ設定
    private int SetTexture()
    {
        // インデックス
        int     Index   = 0;
        string  Name    = null;

        // ヘッダーのテクスチャをセット
        if(Result_Flag == true){
            // テクスチャの変更
            Name = "ResultLen" + 0;
            Child_Image[Result_DataKey.IMAGE_HEADER].sprite = Texture_Dic[Name] as Sprite;
        }
        else{
            Name = "ResultLen" + 1;
            Child_Image[Result_DataKey.IMAGE_HEADER].sprite = Texture_Dic[Name] as Sprite;
        }
       
        // スターマークの表示切替
        this.GetComponent<missionStarController>().SetColor(Star_Flag[0], Star_Flag[1]);

        // ゲームルールテクスチャをセット
        for (int i = 0; i < 2; i++)
        {
            Name = "Rule" + GameRule[i];
            Child_Image[Result_DataKey.IMAGE_RULE_01 + i].sprite = Texture_Dic[Name] as Sprite;
        }
        return 0;
    }

	public void SetViewStar(int idx , bool b)
	{
		Star_Flag[idx] = b;
	}

	public void SetGameState(bool b)
	{
		Result_Flag = b;
	}

	public void SetRule(int one , int two)
	{
		GameRule[0] = one;
		GameRule[1] = two;
	}
}

﻿/////////////////////////////////////////////////////////
//
//	AudioManager
//
//	Data	: 2018/04/23
//	Auther 	: Shun Sakai
//	Memo	: オーディオ制御
//
/////////////////////////////////////////////////////////
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using Common;

public static class AUDIO
{
    public const string BGM_GAME_000    = "BGM_GAME_000";
    public const string BGM_TITLE_000   = "BGM_TITLE_000";
 
    public const string SE_000          = "SE_SHOP_000";
    public const string SE_001          = "SE_SHOP_001";
}

public class AudioManager : Singleton<AudioManager>
{
    // BGMのフェードレート
    private float _bgmFadeSpeedRate = SoundDataKey.BGM_FADE_SPEED_RATE_HIGH;

    // 楽曲予約
    private string _nextBGMName;
    private string _nextSEName;

    // BGMをフェードアウト中か
    private bool _isFadeOut = false;

    // オーディオソース
    public AudioSource AttachBGMSource, AttachSESource;

    // 全楽曲データ
    private Dictionary<string, AudioClip> _bgmDic, _seDic;

    // シーンの保持　シーンチェンジ感知用
    bool m_bgmchange;
    string m_sceneName;
    string m_oldsceneName;

    //=================================================================================
    //初期化
    //=================================================================================
    private void Awake()
    {
        if (this != Instance)
        {
            Destroy(this);
            return;
        }

        //リソースフォルダから全SE&BGMのファイルを読み込みセット
        _bgmDic = new Dictionary<string, AudioClip>();
        _seDic = new Dictionary<string, AudioClip>();

        object[] bgmList = Resources.LoadAll("Audio/BGM");
        object[] seList = Resources.LoadAll("Audio/SE");

        foreach (AudioClip bgm in bgmList)
        {
            _bgmDic[bgm.name] = bgm;
        }
        foreach (AudioClip se in seList)
        {
            _seDic[se.name] = se;
        }

        //現在のシーンの記録
        m_sceneName = SceneManager.GetActiveScene().name;
        m_oldsceneName = m_sceneName;
    }

    private void Start()
    {
        AttachBGMSource.volume = PlayerPrefs.GetFloat(SoundDataKey.BGM_VOLUME_KEY, SoundDataKey.BGM_VOLUME_DEFULT);
        AttachSESource.volume = PlayerPrefs.GetFloat(SoundDataKey.SE_VOLUME_KEY, SoundDataKey.SE_VOLUME_DEFULT);

        //シーン切替用　デリゲートの登録
        SceneManager.activeSceneChanged += OnActiveSceneChanged;
        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.sceneUnloaded += OnSceneUnloaded;

        PlayBGM(AUDIO.BGM_TITLE_000);
        m_bgmchange = true;
    }

    //=================================================================================
    //シーン切替用のデリゲート
    //=================================================================================
    void OnActiveSceneChanged(Scene prevScene, Scene nextScene)
    {
        Debug.Log(prevScene.name + "->" + nextScene.name);
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Debug.Log(scene.name + " scene loaded");
    }

    void OnSceneUnloaded(Scene scene)
    {
        Debug.Log(scene.name + " scene unloaded");
    }

    //=================================================================================
    //SE
    //=================================================================================

    /// <summary>
    /// 指定したファイル名のSEを流す。第二引数のdelayに指定した時間だけ再生までの間隔を空ける
    /// </summary>
    public void PlaySE(string seName, float delay = 0.0f)
    {
        if (!_seDic.ContainsKey(seName))
        {
            Debug.Log(seName + "という名前のSEがありません");
            return;
        }

        _nextSEName = seName;
        Invoke("DelayPlaySE", delay);
    }

    //SEを遅らせる関数
    private void DelayPlaySE()
    {
        AttachSESource.PlayOneShot(_seDic[_nextSEName] as AudioClip);
    }

    //=================================================================================
    // BGM再生
    //=================================================================================
    public void PlayBGM(string bgmName, float fadeSpeedRate = SoundDataKey.BGM_FADE_SPEED_RATE_HIGH)
    {
        if (!_bgmDic.ContainsKey(bgmName))
        {
            Debug.Log(bgmName + "という名前のBGMがありません");
            return;
        }

        //現在BGMが流れていない時はそのまま流す
        if (!AttachBGMSource.isPlaying)
        {
            _nextBGMName = "";
            AttachBGMSource.clip = _bgmDic[bgmName] as AudioClip;
            AttachBGMSource.Play();
        }
        //違うBGMが流れている時は、流れているBGMをフェードアウトさせてから次を流す。同じBGMが流れている時はスルー
        else if (AttachBGMSource.clip.name != bgmName)
        {
            _nextBGMName = bgmName;
            FadeOutBGM(fadeSpeedRate);
        }

    }

    //=================================================================================
    //　BGMフェードアウト処理
    //=================================================================================
    public void FadeOutBGM(float fadeSpeedRate = SoundDataKey.BGM_FADE_SPEED_RATE_LOW)
    {
        _bgmFadeSpeedRate = fadeSpeedRate;
        _isFadeOut = true;
    }
    
    //=================================================================================
    //　更新処理
    //=================================================================================
    private void Update()
    {
        //音楽再生
        BGM_CHANGE();

        if (!_isFadeOut)
        {
            return;
        }

        //徐々にボリュームを下げていき、ボリュームが0になったらボリュームを戻し次の曲を流す
        AttachBGMSource.volume -= Time.deltaTime * _bgmFadeSpeedRate;
        if (AttachBGMSource.volume <= 0)
        {
            AttachBGMSource.Stop();
            AttachBGMSource.volume = PlayerPrefs.GetFloat(SoundDataKey.BGM_VOLUME_KEY, SoundDataKey.BGM_VOLUME_DEFULT);
            _isFadeOut = false;

            if (!string.IsNullOrEmpty(_nextBGMName))
            {
                PlayBGM(_nextBGMName);
            }
        }
    }

    //=================================================================================
    //音量変更
    //=================================================================================
    public void ChangeVolume(float BGMVolume, float SEVolume)
    {
        AttachBGMSource.volume = BGMVolume;
        AttachSESource.volume = SEVolume;

        PlayerPrefs.SetFloat(SoundDataKey.BGM_VOLUME_KEY, BGMVolume);
        PlayerPrefs.SetFloat(SoundDataKey.SE_VOLUME_KEY, SEVolume);
    }

    //=================================================================================
    // BGM切替
    //=================================================================================
    void BGM_CHANGE()
    {
        //フラグ切替処理
        if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name != m_oldsceneName)
        {
            Debug.Log("★再生楽曲を変更しました★");
            m_bgmchange = true;
        }

        //音楽再生処理
        if (m_bgmchange == true)
        {
            //現在のシーンを調べてBGMを再生する
            if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == "Title")
            {
                //PlayBGM(AUDIO.BGM_TITLE_000);
            }
            else if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == "Game")
            {
                PlayBGM(AUDIO.BGM_GAME_000);
            }
            else if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == "Fade")
            {
                FadeOutBGM();
            }
            m_bgmchange = false;
        }
    }

    //=================================================================================
    // SEアタッチ用関数
    //=================================================================================
    public void PUSH_BUTTON_OK()
    {
        AudioManager.Instance.PlaySE(AUDIO.SE_001);
    }

    public void PUSH_BUTTON_NO()
    {
        AudioManager.Instance.PlaySE(AUDIO.SE_000);
    }
}
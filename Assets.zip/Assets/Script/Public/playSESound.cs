﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playSESound : MonoBehaviour {
	[SerializeField]
	private AudioClip clickSound;
	[SerializeField]
	private AudioSource audioSource;

	public void	playClickSound()
	{
		audioSource.PlayOneShot(clickSound);
	}
}

﻿/////////////////////////////////////////////////////////
//
//	PublicSingletonClass
//
//	Data	: 2018/04/23
//	Auther 	: Shun Sakai
//	Memo	: MonoBehaviourを継承した、Singletonクラス
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//=================================================================================
// パブリックシングルトンクラス
//=================================================================================
public class Singleton<T> : MonoBehaviourWithInit where T : MonoBehaviourWithInit
{
    // インスタンス
    private static T _instance;

    // インスタンスを外部から参照する用(getter)
    public static T Instance
    {
        get
        {	// インスタンスがまだ作られていない
            if (_instance == null)
            {
                // シーン内からインスタンスを取得
                _instance = (T)FindObjectOfType(typeof(T));

                // シーン内に存在しない場合はエラー
                if (_instance == null)
                {
                    Debug.LogError(typeof(T) + " is nothing");
                }
                // 発見した場合は初期化
                else
                {
                    _instance.InitIfNeeded();
                }
            }
            return _instance;
        }
    }

    //=================================================================================
    // 初期化
    //=================================================================================
    protected sealed override void Awake()
    {
        // 既存インスタンスが自身であれば問題なし
        if (this == Instance)
        {
            return;
        }
    }

}

//=================================================================================
// 初期化メソッドを備えたMonoBehaviourクラス
//=================================================================================
public class MonoBehaviourWithInit : MonoBehaviour
{
    // 初期化重複防止用のフラグ
    private bool _isInitialized = false;

    // 初期化処理
    public void InitIfNeeded()
    {
        if (_isInitialized)
        {
            return;
        }
        Init();
        _isInitialized = true;
    }

    // 初期化(Unityでの初期化はAwake時、もしくはそれ以前の初アクセス時の一度のみです)
    protected virtual void Init() { }

    // sealed overrideするためにvirtualで作成
    protected virtual void Awake() { }
}
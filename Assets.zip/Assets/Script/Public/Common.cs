﻿/////////////////////////////////////////////////////////
//
//	Commonネーミングスペース
//
//	Data	: 2018/04/23
//	Auther 	: Shun Sakai
//	Memo	: ユーザーが定義したネーミングスペース
//
/////////////////////////////////////////////////////////
using UnityEngine;
using System.Collections;

//=================================================================================
// コモン
//=================================================================================
namespace Common
{
    // デファイン
    public static class Define
    {
        // 共通情報
        public const int FRAME_RATE = 60;               // フレームレート
        public const float BUTTON_NONE_SCALE = 1.0f;    // ボタンスケール値(通常)
        public const float BUTTON_DOWN_SCALE = 0.8f;    // ボタンスケール値(縮小)

        // 初期化用
        public const int INIT_INT   = 0;                // int型初期値
        public const int INIT_DECR  = -1;               // int型DECR値

    }

    // シーン識別子
    public static class Scene_Key
    {
        // シーン番号
        public const int SCENE_TITLE     = 0;  // タイトルモード 
        public const int SCENE_GAME      = 1;  // ゲームモード
    }
    
    // サウンド識別子
    public static class SoundDataKey
    {
        // ボリューム関連
        public const string BGM_VOLUME_KEY      = "BGM_VOLUME_KEY";
        public const float  BGM_VOLUME_DEFULT   = 1.0f;

        public const string SE_VOLUME_KEY       = "SE_VOLUME_KEY";
        public const float  SE_VOLUME_DEFULT    = 1.0f;

        // オーディオファイルパス
        public const string BGM_PATH            = "Audio/BGM";
        public const string SE_PATH             = "Audio/SE";

        // BGMフェード設定
        public const float BGM_FADE_SPEED_RATE_HIGH = 0.9f;
        public const float BGM_FADE_SPEED_RATE_LOW  = 0.3f;
    }

    // ステージサムネイル識別子
    public static class Stage_Select_DataKey
    {
        // ステージ番号
        public const int ITEM_WATER     = 0;  // 水ステージ 
        public const int ITEM_COAL      = 1;  // 石炭ステージ
        public const int ITEM_KONPEITOU = 2;  // 金平糖ステージ 
        public const int ITEM_RUGBY     = 3;  // ラグビーステージ 
        public const int ITEM_SUPERBALL = 4;  // スーパーボールステージ

        // サムネイルファイルパス
        public const string STAGE_PATH  = "Texture/StageSelect/Thumbnail";
        public const string STAGE_LENGTH_PATH = "Texture/Game/UI/stage";
        public const string STAGE_ITEM = "Texture/StageSelect/ItemList";
    }

    // リザルト関連キー
    public static class Result_DataKey
    {
        // ステージ番号
        public const int IMAGE_HEADER   = 0;  // ヘッダ
        public const int IMAGE_STAR_01  = 1;  // 星１
        public const int IMAGE_STAR_02  = 2;  // 星２ 
        public const int IMAGE_RULE_01  = 3;  // ゲームルール１
        public const int IMAGE_RULE_02  = 4;  // ゲームルール２

        // サムネイルファイルパス
        public const string IMAGE_PATH = "Texture/Result/Image";
    }
}

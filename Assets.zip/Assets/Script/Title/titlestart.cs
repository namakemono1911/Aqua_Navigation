﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class titlestart : MonoBehaviour {



	// Use this for initialization
	void Start () {
		int n = this.transform.childCount;
		for(int i = 0; i < n; ++i)
		{

			Transform child = this.transform.GetChild(i);
			child.GetComponent<startFlagManager>().OnStart();
			Debug.Log("スタート : " + child.name);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

﻿/////////////////////////////////////////////////////////
//
//	タイトルＵＩグループ
//
//	Data	: 2018/05/18
//	Auther 	: Shun Sakai
//	Memo	: 
//
/////////////////////////////////////////////////////////
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TitleUi : MonoBehaviour {

    // メンバ
    private SpriteRenderer SpRenderer = null;                 　// スプライトレンダラー
    private CanvasGroup CanvasGroup = null;                     // キャンバスグループ
    private Image[] Child_Image = { null };                 　  // 自身の子要素(imageのみ)

    private Vector2 NormalSize = new Vector2(700.0f, 100.0f);   // 通常時のサムネイルサイズ
    private Vector2 EnlargeSize = new Vector2(800.0f, 120.0f);  // 拡大時のサムネイルサイズ

    // Use this for initialization
    void Start () {

        // コンポーネント取得
        CanvasGroup = this.GetComponent<CanvasGroup>();
        SpRenderer = GetComponent<SpriteRenderer>();

        // 下段レイヤーへの判定を切る
        CanvasGroup.blocksRaycasts = true;
        CanvasGroup.interactable = true;

        // 子要素のイメージコンポーネント取得
        Child_Image = this.GetComponentsInChildren<Image>();

        // 大枠表示のレイキャストをオフへ
        for (int i = 0; i < Child_Image.Length; i++)
        {
            Child_Image[i].raycastTarget = true;
        }
        
        CanvasGroup.alpha = 1f;

        gameObject.SetActive(true);
    }
    
	// Update is called once per frame
	void Update () {
		
	}

    public void GotoStageSelect() {

        FadeManager.FadeOut(1,1.0f);
    }

    // カーソルオン
    public void MauseOn(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオン");

        // イメージ画像の拡大
        Child_Image[Index].GetComponent<RectTransform>().sizeDelta = EnlargeSize;
    }

    // カーソルオフ
    public void MauseOff(int Index)
    {
        // デバッグ表示
        Debug.Log("マウスオフ");


        // イメージ画像の拡大
        Child_Image[Index].GetComponent<RectTransform>().sizeDelta = NormalSize;
    }
}
